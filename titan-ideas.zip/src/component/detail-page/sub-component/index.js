export { default as DetailBannerSection } from "./DetailBannerSection";
export { default as DetailDescription } from "./DetailDescription";
export { default as FeaturedStory } from "./FeaturedStory";
