import React from "react";
import { Logo } from "../../../assets/images";
import {
  SvgFacebookIcon,
  SvgGitIcon,
  SvgInstagramIcon,
  SvgLocationIcon,
  SvgTwitterIcon,
} from "../../../assets/svg-files/SvgFiles";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer>
      <div className="ftr-top">
        <div className="container">
          <div className="ftr-main">
            <div className="ftrtp-lft">
              <div className="ftrtp-logo">
                <img src={Logo} alt="" />
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Nullam dictum aliquet accumsan porta lectus ridiculus in
                  mattis. Netus sodales in volutpat ullamcorper amet adipiscing
                  fermentum.
                </p>
              </div>
              <div className="ftrtp-location">
                <span>
                  <SvgLocationIcon />
                </span>
                <p>
                  Betime Building 246 Macpherson Road #02-03 City:  Singapore
                </p>
              </div>
              <div className="ftrtp-social">
                <div className="ftr-social-icon">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                </div>
                <div className="ftr-social-icon">
                  <Link to="#">
                    <SvgFacebookIcon />
                  </Link>
                </div>
                <div className="ftr-social-icon">
                  <Link to="#">
                    <SvgInstagramIcon />
                  </Link>
                </div>
                <div className="ftr-social-icon">
                  <Link to="#">
                    <SvgGitIcon />
                  </Link>
                </div>
              </div>
            </div>
            <div className="ftrtp-rght">
              <div className="ftrtp-manu">
                <h4>Company</h4>
                <div className="ftrtp-menu-list">
                  <Link to="/">Home</Link>
                  <Link to="/about-us">About</Link>
                  <Link to="/blog">Blogs</Link>
                  <Link to="/forum">Forum</Link>
                </div>
              </div>
              <div className="ftrtp-manu">
                <h4>Quick links</h4>
                <div className="ftrtp-menu-list">
                  <Link to="#">FAQs</Link>
                  <Link to="#">Resources</Link>
                  <Link to="#">Terms & Conditions</Link>
                  <Link to="#">Privacy Policy</Link>
                </div>
              </div>
              <div className="ftrtp-manu">
                <h4>Help Center</h4>
                <div className="ftrtp-menu-list">
                  <Link to="#">Knowledge Base</Link>
                  <Link to="#">Support Tickets</Link>
                  <Link to="#">Live Chat</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="ftr-btm">
        <div className="container">
          <p>© 2025 TitanIdeas. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
