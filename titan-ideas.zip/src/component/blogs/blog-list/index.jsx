import React from "react";
import { BlogBannerSection, FeaturedStory } from "./sub-component";

const index = () => {
  return (
    <>
      <BlogBannerSection />
      <FeaturedStory />
    </>
  );
};

export default index;
