import React, { useState } from "react";
import PaymentSuccessPopup from "./PaymentSuccessPopup";
import { Master, UPI, Visa } from "../assets/images";

const PaymentPopup = ({ handlePopup }) => {
  const [selected, setSelected] = useState(false);

  const [showPaymentSuccessPopup, setPaymentSuccessPopup] = useState(false);
  const handlePaymentSuccessPopupToggle = () => {
    setPaymentSuccessPopup((prev) => !prev);
  };
  
  return (
    <>
      <div className="main-popup payment-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="card">
                <div className="card-body">
                  <div className="form-flex">
                    <div className="form-inner-flex-100">
                      <div className="form-inputs static-amount">
                        <label className="form-label">Total Amount</label>
                        <h4>500$</h4>
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <label className="form-label">
                        Select Payment Option
                      </label>
                      <div className="radio-wappermain">
                        <label className="radio-wrapper">
                          <input
                            type="radio"
                            name="customRadio"
                            checked={selected}
                            onChange={() => setSelected(true)}
                          />
                          <span className="custom-radio" />
                          UPI
                        </label>
                        <div className="upi-imag">
                          <img src={UPI} alt="" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="creditfield-main">
                    <div className="card">
                      <div className="card-body">
                        <div className="form-inner-flex-100">
                          <div className="radio-wappermain">
                            <label className="radio-wrapper">
                              <input
                                type="radio"
                                name="customRadio"
                                checked={selected}
                                onChange={() => setSelected(true)}
                              />
                              <span className="custom-radio" />
                              Credit card
                              <p>Pay securely using your Visa, Maestro</p>
                            </label>
                            <div className="upi-imag credit-upiimage">
                              <img src={Visa} alt="" />
                              <img src={Master} alt="" />
                            </div>
                          </div>
                          <div className="form-flex">
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">
                                  Card Number
                                </label>
                                <input
                                  type="text"
                                  placeholder="1234 5696 5151 5844"
                                />
                              </div>
                            </div>
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">
                                  Name of card
                                </label>
                                <input
                                  type="text"
                                  placeholder="Card holder name"
                                />
                              </div>
                            </div>
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">CVV</label>
                                <input type="text" placeholder="CVV" />
                              </div>
                            </div>
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">
                                  Expire date
                                </label>
                                <input type="text" placeholder="MM/YY" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="payment-btn">
                    <button
                      className="btn btn-primary"
                      onClick={handlePaymentSuccessPopupToggle}
                    >
                      Pay
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>
      {showPaymentSuccessPopup && (
        <PaymentSuccessPopup handlePopup={handlePaymentSuccessPopupToggle} />
      )}
    </>
  );
};

export default PaymentPopup;
