import React from "react";
import { Link } from "react-router-dom";

const PaymentSuccessPopup = ({ handlePopup }) => {
  return (
    <>
      <div className="main-popup paymentsuccess-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="card">
                <div className="card-body">
                  <div className="paymentsuccess-heading">
                    <svg
                      width="155"
                      height="155"
                      viewBox="0 0 155 155"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M115.596 48.6466C117.888 50.9293 117.896 54.6378 115.613 56.9298L66.2604 106.483C63.9778 108.775 60.2694 108.782 57.9774 106.5L39.9788 88.5759C37.6867 86.2933 37.679 82.5848 39.9615 80.2927C42.2441 78.0006 45.9527 77.9929 48.2448 80.2755L62.0934 94.0666L107.313 48.6634C109.596 46.3714 113.304 46.3639 115.596 48.6466Z"
                        fill="#D7B434"
                      />
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M77.1586 12.2143C46.1114 12.2143 20.065 33.8937 13.379 62.9361L13.379 62.9362C12.2906 67.6635 11.7143 72.5909 11.7143 77.6586C11.7143 113.775 41.0421 143.103 77.1586 143.103C113.275 143.103 142.603 113.775 142.603 77.6586C142.603 41.5421 113.275 12.2143 77.1586 12.2143ZM1.96331 60.308C9.8455 26.0697 40.53 0.5 77.1586 0.5C119.745 0.5 154.317 35.0725 154.317 77.6586C154.317 120.245 119.745 154.817 77.1586 154.817C34.5725 154.817 0 120.245 0 77.6586C0 71.6999 0.677961 65.8909 1.96331 60.308Z"
                        fill="#D7B434"
                      />
                    </svg>
                    <h3>Payment successful</h3>
                    <p>Your payment has been successfully</p>
                  </div>
                  <div className="successfully-btn">
                    <Link
                      to="/home"
                      className="btn btn-primary"
                      onClick={handlePopup}
                    >
                      Back to Home
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>
    </>
  );
};

export default PaymentSuccessPopup;
