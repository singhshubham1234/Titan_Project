import React, { useState } from "react";
import Select from "react-select";
import MediaUploader from "./MediaUploader";
import WarningPopup from "./WarningPopup";

const IdeaSharePopup = ({ handlePopup }) => {
  const Domain = [
    { value: "Domain", label: "Domain" },
    { value: "Tech", label: "Tech" },
    { value: "Education", label: "Education" },
  ];
  const [showWarningPopup, setWarningPopup] = useState(false);
  const handleWarningPopupToggle = () => {
    setWarningPopup((prev) => !prev);
  };

  return (
    <>
      <div className="main-popup ideashare-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="shareideas-main">
                <div className="shareideas-form">
                  <div className="shareideas-heading">
                    <h3>Share an Idea</h3>
                    <p>Take Your Idea Further, Faster with Titan</p>
                  </div>
                  <div className="form-flex">
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <Select
                          options={Domain}
                          placeholder="Select a domain"
                        />
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Title</label>
                        <input type="text" placeholder="Title" />
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Description</label>
                        <textarea
                          cols={4}
                          rows={4}
                          type="text"
                          className="form-control"
                          placeholder="Tell us a little about the Idea..."
                        />
                      </div>
                    </div>
                  </div>
                  <div className="shareideas-btn">
                    <button
                      className="btn btn-primary"
                      onClick={handleWarningPopupToggle}
                    >
                      Submit
                    </button>
                    <button className="btn btn-secondary" onClick={handlePopup}>
                      Cancel
                    </button>
                  </div>
                </div>
                <div className="shareideas-format">
                  <div className="format-heading">
                    <h4>Follow the format :</h4>
                    <p>
                      Fill out our simple submission form, based on our
                      guidelines and let our community and experts help you
                      refine it.
                    </p>
                  </div>
                  <div className="format-list">
                    <p>
                      <span></span>Evaluate the impact and scalability of the
                      idea.
                    </p>
                    <p>
                      <span></span>Analyses the economic feasibility of the
                      idea.
                    </p>
                    <p>
                      <span></span>Evaluates the practical realism of the idea.
                    </p>
                    <p>
                      <span></span>Measure the uniqueness and originality of the
                      idea.
                    </p>
                  </div>
                  <MediaUploader />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>
      {showWarningPopup && (
        <WarningPopup handlePopup={handleWarningPopupToggle} />
      )}
      
    </>
  );
};

export default IdeaSharePopup;
