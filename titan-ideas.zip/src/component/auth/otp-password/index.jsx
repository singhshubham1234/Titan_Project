import React, { useState } from "react";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import "react-phone-number-input/style.css";
import OTPInput from "react-otp-input";
import { Link } from "react-router-dom";
const index = () => {
  const [otp, setOtp] = useState("");
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>
                        Verification
                      </h3>
                      <p>
                        Enter your email or phone number for the verification
                        process, we will send 4 digits code to your device.
                      </p>
                    </div>
                    <div className="otp-input">
                      <OTPInput
                        containerStyle="otp-flex"
                        value={otp}
                        onChange={setOtp}
                        numInputs={4}
                        renderSeparator={""}
                        skipDefaultStyles={true}
                        renderInput={(props) => (
                          <input
                            {...props}
                            placeholder="-"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            onKeyPress={(e) => {
                              if (!/[0-9]/.test(e.key)) {
                                e.preventDefault();
                              }
                            }}
                          />
                        )}
                      />
                    </div>
                    <div className="otp-timer">
                      <span>00:30</span>
                    </div>
                    <div className="auth-btn">
                      <Link to="/new-password" className="btn btn-primary">Continue</Link>
                    </div>
                    <div className="donthave-account">
                      <p>
                        If you didn’t receive a code!{" "}
                        <Link to="/sign-up">Resend</Link>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
