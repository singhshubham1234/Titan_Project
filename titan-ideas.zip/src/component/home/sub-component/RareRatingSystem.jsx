import React from "react";
import { Rare1, Rare2, Rare3, Rare4 } from "../../../assets/images";

const RareRatingSystem = () => {
  const rareRatingSystemData = [
    {
      image: Rare4,
      title: "REACH",
      subTitle: "How far can your idea go?",
      Description:
        "Evaluates the impact and scalability of your idea, considering market size, potential users, and global reach. It also assesses how quickly your idea can be adopted and grow through sharing.",
    },

    {
      image: Rare3,
      title: "AFFORDABILITY",
      subTitle: "Is it cost effective??",
      Description:
        "Analyses the economic feasibility of your idea. This involves a cost-benefit analysis to ensure that the benefits outweigh the costs and budget planning to determine if the idea is financially viable within set budgets.",
    },
    {
      image: Rare2,
      title: "RATIONALITY",
      subTitle: "Does it make sense?",
      Description:
        "Assesses the logical foundation of your idea. It evaluates practicality and feasibility to determine if the idea can be realistically implemented and ensures the problem-solution fit effectively addresses a specific problem or need.",
    },
    {
      image: Rare1,
      title: "EXCLUSIVITY",
      subTitle: "Is it unique?",
      Description:
        "Measures the uniqueness and originality of your idea. It identifies the competitive advantage, highlighting what sets your idea apart from others, and evaluates the innovative edge that makes your idea stand out.",
    },
  ];

  return (
    <section className="rarerating-section">
      <div className="container">
        <div className="top-heading">
          <h5>Beyond Stars, Deeper Insights</h5>
          <h3>The RARE Rating System</h3>
          <p>
            The RARE rating system comprehensively evaluates and validates your
            ideas, ensuring they are robust and ready for implementation.
          </p>
        </div>
        <div className="rarerating-list">
          <ul>
            {rareRatingSystemData.map((item, index) => (
              <li key={index}>
                <div className="rarerating-card">
                  <div className="rarerating-image">
                    <img src={item.image} alt={item.title} />
                  </div>
                  <h3>{item.title}</h3>
                  <h5>{item.subTitle}</h5>
                  <p>{item.Description}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export default RareRatingSystem;
