import React from "react";
import { Testimonial1 } from "../../../assets/images";
import {
  SvgDegreeLongArrowIcon,
  SvgStarIcon,
} from "../../../assets/svg-files/SvgFiles";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from "react-router-dom";
const Testimonial = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500, // Slide transition speed (milliseconds)
    autoplay: true,
    autoplaySpeed: 3000, // Slide change hone ka interval (milliseconds)
    slidesToShow: 2, // Ek saath 2 slides dikhane ke liye
    slidesToScroll: 1, // Ek slide scroll hogi
    arrows: false, // Arrows hide karne ke liye
  };
  return (
    <section className="testimonial-section">
      <div className="container">
        <div className="top-heading mb-50">
          <h5>Your Idea, Our Mission</h5>
          <h3>What Our Innovators Say</h3>
        </div>
        <Slider {...settings} className="testimonial-slider">
          {[1, 2, 3, 4].map((_, index) => (
            <div key={index} className="testimonial-crd">
              <div className="testimonial-img">
                <img src={Testimonial1} alt="Testimonial" />
              </div>
              <div className="testimonial-content">
                <div className="testimonial-rating">
                  {[...Array(5)].map((_, i) => (
                    <span key={i}>
                      <SvgStarIcon />
                    </span>
                  ))}
                </div>
                <p>
                  "We love Titan Ideas! Our designers were using it for their
                  projects, so we already knew what kind of design they want."
                </p>
                <div className="testimonial-title">
                  <h6>Jenny Wilson</h6>
                  <span>Grower.io</span>
                </div>
              </div>
            </div>
          ))}
        </Slider>
        <div className="featured-viewsbtn">
          <Link to="/blog">
            View All
            <span>
              <SvgDegreeLongArrowIcon />
            </span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;
