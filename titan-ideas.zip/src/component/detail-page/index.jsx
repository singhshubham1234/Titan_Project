import React from "react";
import { DetailBannerSection, DetailDescription, FeaturedStory } from "./sub-component";

const index = () => {
  return (
    <>
      <DetailBannerSection />
      <DetailDescription />
      <FeaturedStory/>
    </>
  );
};

export default index;
