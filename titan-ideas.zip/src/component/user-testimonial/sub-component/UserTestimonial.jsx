import React, { useState } from "react";

import Pagination from "../../../helper/Pagination";
import { ExpertImage1 } from "../../../assets/images";
import { SvgStarSmallIcon } from "../../../assets/svg-files/SvgFiles";
import { Link } from "react-router-dom";

const UserTestimonial = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleReadMore = () => {
    setIsExpanded((prev) => !prev);
  };

  const testimonials = [
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },
    {
      name: "Ankit",
      role: "Lead Designer",
      rating: "30/40",
      image: ExpertImage1,
      title: "It was a very good experience",
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
      eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
      felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
      pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
    },

    // Add more objects here...
  ];
  return (
    <section className="usertestimonial-section">
      <div className="container">
        <div className="top-heading">
          <h3>User Testimonial</h3>
        </div>
        <div className="usertestimonial-list">
          <ul>
            {testimonials.map((item, index) => (
              <li key={index}>
                <div className="usertestimonial-card">
                  <div className="usertestimonial-profilerating">
                    <div className="usertestimonial-profile">
                      <span
                        style={{ backgroundImage: `url(${item.image})` }}
                      ></span>
                      <h4>{item.name}</h4>
                      <p>{item.role}</p>
                    </div>
                    <div className="usertestimonial-rating">
                      <p>
                        Rating:{item.rating} <SvgStarSmallIcon />
                      </p>
                    </div>
                  </div>
                  <div className="usertestimonial-description">
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <Link to="/detail" className="read-more">
                      Read more
                    </Link>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <Pagination />
      </div>
    </section>
  );
};

export default UserTestimonial;
