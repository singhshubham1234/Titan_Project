import React from "react";

const DetailDescription = () => {
  return (
    <section className="detaildescription-section">
      <div className="container">
        <div className="detail-description">
          <h3>Meet Amelia Bennett, CEO of 'TechBloom'</h3>
          <p>
            Since its inception, TechBloom has experienced rapid growth, serving
            over a hundred major clients across various sectors. The company's
            revenue has increased by 250% in the last three years, and they've
            received multiple awards for innovation and sustainability.
            TechBloom is also committed to community engagement, regularly
            hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives. Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.Since its inception, TechBloom has experienced rapid
            growth, serving over a hundred major clients across various sectors.
            The company's revenue has increased by 250% in the last three years,
            and they've received multiple awards for innovation and
            sustainability. TechBloom is also committed to community engagement,
            regularly hosting workshops and contributing to environmental
            initiatives.
          </p>
          <h4>The TechBloom Story</h4>
          <p>
            TechBloom, founded by Amelia Bennett, emerged from a vision to
            create innovative software that enhances workplace productivity
            while prioritizing environmental sustainability. Starting in a small
            home office, Amelia's relentless pursuit of excellence and
            commitment to ethical practices quickly propelled TechBloom to
            become a leader in the industry.
          </p>
          <h4>The TechBloom Story</h4>
          <p>
            TechBloom, founded by Amelia Bennett, emerged from a vision to
            create innovative software that enhances workplace productivity
            while prioritizing environmental sustainability. Starting in a small
            home office, Amelia's relentless pursuit of excellence and
            commitment to ethical practices quickly propelled TechBloom to
            become a leader in the industry.
          </p>
          <p>
            TechBloom, founded by Amelia Bennett, emerged from a vision to
            create innovative software that enhances workplace productivity
            while prioritizing environmental sustainability. Starting in a small
            home office, Amelia's relentless pursuit of excellence and
            commitment to ethical practices quickly propelled TechBloom to
            become a leader in the industry.
          </p>
          <p>
            TechBloom, founded by Amelia Bennett, emerged from a vision to
            create innovative software that enhances workplace productivity
            while prioritizing environmental sustainability. Starting in a small
            home office, Amelia's relentless pursuit of excellence and
            commitment to ethical practices quickly propelled TechBloom to
            become a leader in the industry.
          </p>
          <h4>The TechBloom Story</h4>
          <p>
            TechBloom, founded by Amelia Bennett, emerged from a vision to
            create innovative software that enhances workplace productivity
            while prioritizing environmental sustainability. Starting in a small
            home office, Amelia's relentless pursuit of excellence and
            commitment to ethical practices quickly propelled TechBloom to
            become a leader in the industry.
          </p>
        </div>
      </div>
    </section>
  );
};

export default DetailDescription;
