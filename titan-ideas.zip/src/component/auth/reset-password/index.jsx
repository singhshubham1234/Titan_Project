import React from "react";
import { Link } from "react-router-dom";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";

const index = () => {
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>
                        Reset Password
                      </h3>
                      <p>
                        Enter your email or phone number for the verification
                        process, we will send 4 digits code to your device.
                      </p>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="form-flex">
                            <div className="form-inner-flex-100">
                              <label className="form-label">
                                Email or Phone no.
                              </label>
                              <input
                                type="num"
                                placeholder="Enter your registered Email or Phone Number"
                              />
                            </div>
                          </div>
                          <div className="auth-btn">
                            <Link to="/otp-password" className="btn btn-primary">
                              Continue
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
