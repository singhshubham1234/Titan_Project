import React from "react";
import {
  ExpertImage1,
  ExpertImage2,
  ExpertImage3,
  ExpertImage4,
} from "../../../../assets/images";

const AllFollowerTab = () => {
  const followers = [
    {
      avatar: ExpertImage1,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: null,
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Innovator", type: "innovator" },
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Occupational",
      badge: null,
    },
    {
      avatar: ExpertImage4,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Expert", type: "expert" },
    },
    {
      avatar: ExpertImage1 ,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Expert", type: "expert" },
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Epidemiologist",
      badge: { label: "Contributor", type: "contributor" },
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Public Health Officer",
      badge: null,
    },
  ];

  return (
    <div className="follower-list">
      {followers.map((follower, index) => (
        <div key={index} className="follower-card">
          <img src={follower.avatar} alt={follower.name} className="avatar" />
          <div className="follower-info">
            <div className="follower-name">
              {follower.name}
              {follower.badge && (
                <span className={`badge ${follower.badge.type}`}>
                  {follower.badge.label}
                </span>
              )}
            </div>
            <div className="follower-role">
              {follower.profession} <span className="follow-link">/ Follow</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AllFollowerTab;
