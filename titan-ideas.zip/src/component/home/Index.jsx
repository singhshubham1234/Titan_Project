import React from "react";
import {
  BannerSection,
  DiscoverSection,
  ExpertsTrustSection,
  JoinUsSection,
  RareRatingSystemSection,
  ShareIdeasSection,
  TestimonialSection,
} from "./sub-component";

const Index = () => {
  return (
    <>
      <BannerSection />
      <DiscoverSection />
      <RareRatingSystemSection />
      <ShareIdeasSection />
      <ExpertsTrustSection />
      <TestimonialSection />
      <JoinUsSection/>
    </>
  );
};

export default Index;
