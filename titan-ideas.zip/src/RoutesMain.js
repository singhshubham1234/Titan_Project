export { default as LoginPage } from './component/auth/login'
export { default as SignInPage } from './component/auth/signup'
export { default as TellUsPage } from './component/auth/tell-us-more'
export { default as ExpertVerification } from './component/auth/expert-verification'
export { default as ResetPasswordPage } from './component/auth/reset-password'
export { default as OtpPasswordPage } from './component/auth/otp-password'
export { default as NewPasswordPage } from './component/auth/new-password'
export { default as SuccessPage } from './component/auth/success'
export { default as VerificationSuccessPage } from './component/auth/verification-success'


export { default as HomePage } from "./component/home/Index";
export { default as AboutUsPage } from "./component/about-us";
export { default as BlogPage } from "./component/blogs/blog-main";
export { default as BlogListPage } from "./component/blogs/blog-list";
export { default as UserTestimonialPage } from "./component/user-testimonial";
export { default as TestimonialExpertDetailPage } from "./component/testimonial-expert-detail";
export { default as ForumPage } from "./component/forum";
export { default as ExpertPage } from "./component/experts";
export { default as DetailPage } from "./component/detail-page";
export { default as ContactPage } from "./component/contact";

// sidebar dashboard
export { default as PostPage } from "./dashboard/home";
export { default as ProfilePage } from "./dashboard/profile";
export { default as SubscriptionPage } from "./dashboard/subcription";
export { default as PaymentPage } from "./dashboard/payment";
export { default as NotificationPage } from "./dashboard/notification";

