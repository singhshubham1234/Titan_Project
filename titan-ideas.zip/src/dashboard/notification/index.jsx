import React from "react";
import Notification from "./sub-component/Notification";

const index = () => {
  return (
    <>
      <Notification />
    </>
  );
};

export default index;
