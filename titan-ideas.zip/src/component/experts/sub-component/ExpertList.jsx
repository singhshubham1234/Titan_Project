import React from "react";
import { ExpertProfile } from "../../../assets/images";
import Pagination from "../../../helper/Pagination";
import { Link } from "react-router-dom";

const expertData = Array.from({ length: 15 }, (_, i) => ({
  id: i + 1,
  title: "It was a very good experience",
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eu rhoncus urna facilisis quisque orci lectus sed nulla. amet, consectetur adipiscing Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eu rhoncus urna facilisis quisque orci lectus sed nulla. amet, consectetur adipiscing",
  image: ExpertProfile,
}));
const ExpertList = () => {
  return (
    <section className="expertlist-section">
      <div className="container">
        <div className="top-heading">
          <h3>Expert Highlights</h3>
        </div>
        <div className="expertlist-list">
          <ul>
            {expertData.map((item) => (
              <li key={item.id}>
                <Link to="/detail" className="expertlist-card">
                  <div className="expertlist-description">
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <div className="expertlist-arrow"></div>
                  </div>
                  <div className="expertlist-image">
                    <span
                      style={{ backgroundImage: `url(${item.image})` }}
                    ></span>
                    <h3>Lucky</h3>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <Pagination />
      </div>
    </section>
  );
};

export default ExpertList;
