import React from "react";
import {
  FeaturedImage1,
  FeaturedImage2,
  FeaturedImage3,
} from "../../../../assets/images";
import { Link } from "react-router-dom";
import { SvgDegreeLongArrowIcon } from "../../../../assets/svg-files/SvgFiles";

const FeaturedStory = () => {
  const featuredItems = [
    {
      image: FeaturedImage1,
      author: "Ankit Verma",
      title: "Our top 10 Javascript frameworks to use",
      description:
        "JavaScript frameworks make development easy with extensive features and functionalities...",
    },
    {
      image: FeaturedImage2,
      author: "Alisha Gupta",
      title: "Podcast: Creating a better CX Community",
      description:
        "Starting a community doesn’t need to be complicated, but how do...",
    },
    {
      image: FeaturedImage3,
      author: "Shikha",
      title: "How collaboration makes us better designers",
      description:
        "Collaboration can make our teams stronger, and our individual designs better...",
    },
    {
      image: FeaturedImage2,
      author: "Alisha Gupta",
      title: "Podcast: Creating a better CX Community",
      description:
        "Starting a community doesn’t need to be complicated, but how do...",
    },
    {
      image: FeaturedImage3,
      author: "Shikha",
      title: "How collaboration makes us better designers",
      description:
        "Collaboration can make our teams stronger, and our individual designs better...",
    },
    {
      image: FeaturedImage1,
      author: "Ankit Verma",
      title: "Our top 10 Javascript frameworks to use",
      description:
        "JavaScript frameworks make development easy with extensive features and functionalities...",
    },
  ];

  return (
    <section className="featuredstory-section">
      <div className="container">
        <div className="top-heading">
          <h3>Featured Stories</h3>
        </div>
        <div className="featured-list">
          <ul>
            {featuredItems.map((item, index) => (
              <li key={index}>
                <div className="featured-card">
                  <div className="featured-image">
                    <span
                      style={{ backgroundImage: `url(${item.image})` }}
                    ></span>
                  </div>
                  <div className="featured-descption">
                    <h6>{item.author}</h6>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <Link to="/blog-detail">Read more</Link>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="featured-viewsbtn">
          <Link to="/blog-list">
            View All
            <span>
              <SvgDegreeLongArrowIcon />
            </span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedStory;
