import React from "react";
import Contact from "./sub-component/Contact";

const index = () => {
  return (
    <>
      <Contact />
    </>
  );
};

export default index;
