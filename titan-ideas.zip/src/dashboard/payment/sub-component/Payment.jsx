import React, { useState } from "react";
import { Master, UPI, Visa } from "../../../assets/images";
import PaymentSuccessPopup from "../../../helper/PaymentSuccessPopup";

const Payment = () => {
  const [selected, setSelected] = useState(false);
  const [showPaymentSuccessPopup, setPaymentSuccessPopup] = useState(false);
  const handlePaymentSuccessPopupToggle = () => {
    setPaymentSuccessPopup((prev) => !prev);
  };
  return (
    <>
      <div className="payment-section">
        <div className="payment-main">
          <div className="card">
            <div className="card-body">
              <div className="form-flex">
                <div className="form-inner-flex-100">
                  <div className="form-inputs">
                    <label className="form-label">Total Amount</label>
                    <input type="text" placeholder="$500" />
                  </div>
                </div>
                <div className="form-inner-flex-100">
                  <label className="form-label">Select Payment Option</label>
                  <div className="radio-wappermain">
                    <label className="radio-wrapper">
                      <input
                        type="radio"
                        name="customRadio"
                        checked={selected}
                        onChange={() => setSelected(true)}
                      />
                      <span className="custom-radio" />
                      UPI
                    </label>
                    <div className="upi-imag">
                      <img src={UPI} alt="" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="creditfield-main">
                <div className="card">
                  <div className="card-body">
                    <div className="form-inner-flex-100">
                      <div className="radio-wappermain">
                        <label className="radio-wrapper">
                          <input
                            type="radio"
                            name="customRadio"
                            checked={selected}
                            onChange={() => setSelected(true)}
                          />
                          <span className="custom-radio" />
                          Credit card
                          <p>Pay securely using your Visa, Maestro</p>
                        </label>
                        <div className="upi-imag credit-upiimage">
                          <img src={Visa} alt="" />
                          <img src={Master} alt="" />
                        </div>
                      </div>
                      <div className="form-flex">
                        <div className="form-inner-flex-50">
                          <div className="form-inputs">
                            <label className="form-label">Card Number</label>
                            <input type="text" placeholder="$0" />
                          </div>
                        </div>
                        <div className="form-inner-flex-50">
                          <div className="form-inputs">
                            <label className="form-label">Name of card</label>
                            <input type="text" placeholder="$500" />
                          </div>
                        </div>
                        <div className="form-inner-flex-50">
                          <div className="form-inputs">
                            <label className="form-label">CVV</label>
                            <input type="text" placeholder="$500" />
                          </div>
                        </div>
                        <div className="form-inner-flex-50">
                          <div className="form-inputs">
                            <label className="form-label">Expire date</label>
                            <input type="text" placeholder="$500" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="payment-btn">
                <button
                  className="btn btn-primary"
                  onClick={handlePaymentSuccessPopupToggle}
                >
                  Pay
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showPaymentSuccessPopup && (
        <PaymentSuccessPopup handlePopup={handlePaymentSuccessPopupToggle} />
      )}
    </>
  );
};

export default Payment;
