import React from "react";
import { SvgPlayFillIcon } from "../../../assets/svg-files/SvgFiles";
import { WorkImage } from "../../../assets/images";

const HowItWorks = () => {
  return (
    <section className="work-section">
      <div className="container">
        <div className="top-heading">
          <h5>HOW IT WORKS</h5>
          <h3>
            Unlock the potential of your ideas with our step-by-step process.
          </h3>
         
        </div>
        <div
            className="work-video"
            style={{ backgroundImage: `url(${WorkImage})` }}
          >
            <span>
              <SvgPlayFillIcon />
            </span>
          </div>
      </div>
    </section>
  );
};

export default HowItWorks;
