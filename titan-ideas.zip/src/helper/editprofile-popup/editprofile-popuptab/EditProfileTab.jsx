import React from "react";

const EditProfileTab = () => {
  return (
    <div className="editprofile-form">
      <div className="form-flex">
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">First Name</label>
            <input type="text" placeholder="Your First Name" />
          </div>
        </div>
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">Last name</label>
            <input type="text" placeholder="Your last Name" />
          </div>
        </div>
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">Email Address</label>
            <input type="text" placeholder="xyz@gmail.com" />
          </div>
        </div>
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">Phone Number</label>
            <input type="text" placeholder="+91-15849877878" />
          </div>
        </div>
        <div className="form-inner-flex-100">
          <div className="form-inputs">
            <label className="form-label">About</label>
            <textarea
              type="text"
              placeholder="$About..............."
              cols={4}
              rows={4}
            />
          </div>
        </div>
      </div>
      <div className="editprofile-btn">
        <button className="btn btn-info">Cancel</button>
        <button className="btn btn-primary">Update</button>
      </div>
    </div>
  );
};

export default EditProfileTab;
