import React from 'react'
import { ExpertList, ExpertsBannerSection } from './sub-component'

const index = () => {
  return (
    <>
    <ExpertsBannerSection/>
    <ExpertList/>
    </>
  )
}

export default index