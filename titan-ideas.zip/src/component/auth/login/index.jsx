import React, { useState } from "react";
import { Link } from "react-router-dom";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import {
  SvgGoogleIcon,
  SvgDashLinkdinIcon,
} from "../../../assets/svg-files/SvgFiles";
const index = () => {
  const [selected, setSelected] = useState("user");

  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        {" "}
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>{" "}
                        Login{" "}
                      </h3>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="select-tabbing">
                            <div className="radio-tab-group">
                              <label
                                className={`radio-tab ${
                                  selected === "user" ? "active" : ""
                                }`}
                              >
                                <input
                                  type="radio"
                                  name="tab"
                                  value="user"
                                  checked={selected === "user"}
                                  onChange={() => setSelected("user")}
                                />
                                <span className="custom-radio"></span>
                                User
                              </label>

                              <label
                                className={`radio-tab ${
                                  selected === "expert" ? "active" : ""
                                }`}
                              >
                                <input
                                  type="radio"
                                  name="tab"
                                  value="expert"
                                  checked={selected === "expert"}
                                  onChange={() => setSelected("expert")}
                                />
                                <span className="custom-radio"></span>
                                Expert
                              </label>
                            </div>
                          </div>
                          <div className="form-flex">
                            <div className="form-inner-flex-100">
                              <label className="form-label">Email</label>
                              <input type="num" placeholder="JBVBYHV89785" />
                            </div>
                            <div className="form-inner-flex-100">
                              <div className="form-inputs">
                                <label className="form-label">Password</label>
                                <div className="input-wthicon">
                                  <input
                                    type="password"
                                    placeholder="Enter Your Password"
                                  />
                                  <div className="input-icon">
                                    <span>
                                      <i className="fa-regular fa-eye"></i>
                                    </span>
                                    <span style={{ display: "none" }}>
                                      <i className="fa-regular fa-eye-slash"></i>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="frgot-btn">
                            <Link to="/reset-password">Forgot Password?</Link>
                          </div>
                          <div className="auth-btn">
                            <Link to="/" className="btn btn-primary">
                              WithoutLogin
                            </Link>
                            <Link to="/home" className="btn btn-primary">
                              WithLogin
                            </Link>
                          </div>
                          <div className="donthave-account">
                            <p>
                              New to Titan?{" "}
                              <Link to="/sign-up">Sign Up Here</Link>
                            </p>
                          </div>
                          <div className="auth-divided">
                            <p>Or With</p>
                          </div>
                          <div className="socail-list">
                            <div className="auth-socaillink">
                              <Link to="#" className="btn btn-secondary ">
                                <span>
                                  <SvgGoogleIcon />
                                </span>
                                Sign in with Google
                              </Link>
                            </div>
                            <div className="auth-socaillink">
                              <Link to="#" className="btn btn-secondary ">
                                <span>
                                  <SvgDashLinkdinIcon />
                                </span>
                                Sign in with Linkedin
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
