import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  SvgDashboardAboutIcon,
  SvgDashboardBlogIcon,
  SvgDashboardContentIcon,
  SvgDashboardForumIcon,
  SvgDashboardHomeIcon,
  SvgDashboardNotificationIcon,
  SvgDashboardPluseIcon,
  SvgDashboardProfileIcon,
} from "../../../assets/svg-files/SvgFiles";
import { Logo } from "../../../assets/images";
import IdeaSharePopup from "../../../helper/IdeaSharePopup";

const sidebarMenu = [
  {
    name: "Home",
    link: "/home",
    svg: <SvgDashboardHomeIcon />,
  },
  {
    name: "About us",
    link: "/about-us",
    svg: <SvgDashboardAboutIcon />,
  },
  {
    name: "Blogs",
    link: "/blog",
    svg: <SvgDashboardBlogIcon />,
  },
  {
    name: "Forums",
    link: "/forum",
    svg: <SvgDashboardForumIcon />,
  },
  {
    name: "Contact",
    link: "/contact",
    svg: <SvgDashboardContentIcon />,
  },
  {
    name: "Profile",
    link: "/home/profile",
    svg: <SvgDashboardProfileIcon />,
  },
  {
    name: "Notification",
    link: "/home/notification",
    svg: <SvgDashboardNotificationIcon />,
  },
];

const SideBar = () => {
  const location = useLocation();
  const activePath = location.pathname;

  const activeSubMenus = sidebarMenu.findIndex((item) =>
    item.submenus?.some((subMenus) => activePath.startsWith(subMenus.link))
  );

  const [expandSubMenus, setExpandSubMenus] = useState(activeSubMenus);

  const handleToggle = (idx) => {
    setExpandSubMenus((prev) => (prev === idx ? null : idx));
  };

  // const addClass = () => {
  //   document.body.classList.toggle("open-sidebar");
  // };
  const [showIdeaSharePopup, setIdeaSharePopup] = useState(false);
  const handleIdeaSharePopupToggle = () => {
    setIdeaSharePopup((prev) => !prev);
  };
  return (
    <>
      <aside className="sidenav">
        <div className="sidebar-top">
          <div className="logo-main">
            <span className="logo">
              <img src={Logo} alt="Logo" />
            </span>
          </div>
          <div className="sidebarinner-main">
            <div className="sidebarinner-btn">
              <button
                className="btn btn-primary"
                onClick={handleIdeaSharePopupToggle}
              >
                <SvgDashboardPluseIcon /> Submit New Idea
              </button>
              <Link to="/home/subscription">
                <span>
                  <svg
                    fill="#000000"
                    viewBox="0 -5.47 56.254 56.254"
                    xmlns="http://www.w3.org/2000/svg"
                    width={20}
                    height={20}
                  >
                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                    <g
                      id="SVGRepo_tracerCarrier"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></g>
                    <g id="SVGRepo_iconCarrier">
                      <path
                        id="diamond_premium"
                        data-name="diamond premium"
                        d="M494.211,354.161l1.174-1.366H482.552L469.8,367.5h12.94Zm-8.4,13.336H510.05l-6.589-7.664-5.528-6.429-8.354,9.713Zm-15.856,2.329,24.1,25.356L482.53,369.826Zm40.824,0h-2.1l-8.829,0H485.083l12.774,28.1.082.178,12.17-26.8Zm-8.94,25.322,24.057-25.32H513.337Zm24.215-27.65L513.3,352.8H500.478l12.642,14.7Z"
                        transform="translate(-469.802 -352.795)"
                      ></path>
                    </g>
                  </svg>
                </span>
                Go To Premium
              </Link>
            </div>
            {/* <div className="navmenu-sidbar">
            <div className="navbar-icon" onClick={addClass}>
              <span></span>
            </div>
          </div> */}
            <div className="navbar-inner">
              <ul>
                {sidebarMenu.map((menus, idx) => (
                  <li
                    key={idx}
                    className={`menu-item here ${
                      idx === expandSubMenus && menus.submenus
                        ? "menu-accordion"
                        : ""
                    }`}
                  >
                    <Link
                      onClick={() => handleToggle(idx)}
                      to={!menus.submenus ? menus.link : "#"}
                      className={`menu-link ${
                        expandSubMenus === idx ? "active" : ""
                      } ${
                        !menus.submenus && activePath === menus.link
                          ? "active"
                          : ""
                      }`}
                    >
                      <span className="menu-icon">{menus.svg}</span>
                      <span className="menu-title">{menus.name}</span>
                      {menus.submenus && <span className="menu-arrow"></span>}
                    </Link>
                    {menus.submenus && (
                      <div
                        className={`menu-sub menu-sub-accordion menu-active-bg overflw-hdn ${
                          expandSubMenus === idx ? "max-h-400" : "max-h-0"
                        }`}
                      >
                        {menus.submenus.map((subMenus, subIdx) => (
                          <div key={subIdx} className="menu-item">
                            <Link
                              className={`menu-link ${
                                activePath === subMenus.link ? "active" : ""
                              }`}
                              to={subMenus.link}
                            >
                              <span className="menu-bullet">
                                <span className="bullet bullet-dot"></span>
                              </span>
                              <span className="menu-title">
                                {subMenus.name}
                              </span>
                            </Link>
                          </div>
                        ))}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
              <div className="advertisement">Advertisement</div>
            </div>
          </div>
        </div>
      </aside>
      {showIdeaSharePopup && (
        <IdeaSharePopup handlePopup={handleIdeaSharePopupToggle} />
      )}
    </>
  );
};

export default SideBar;
