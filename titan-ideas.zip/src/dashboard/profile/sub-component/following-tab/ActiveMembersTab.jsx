import React from 'react'

const ActiveMembersTab = () => {
  return (
    <div>ActiveMembersTab</div>
  )
}

export default ActiveMembersTab