import React from "react";
import Select from "react-select";
import { SvgSearchIcon } from "../../../assets/svg-files/SvgFiles";
import ProfileDropdown from "../../../helper/ProfileDropdown";
function Header() {
  const addClass = () => {
    document.body.classList.toggle("open-sidebar");
  };
  const SelectClient = [{ value: "Select", label: "Select" }];

  return (
    <>
      <topbar className="dashboard-header">
        <div className="main-header">
          <div className="lft-hdr">
            <div className="navmenu-hdr">
              <div className="navbar-icon" onClick={addClass}>
                <span></span>
              </div>
            </div>
            <div className="navmenu-searchicon">
              <span>
                <SvgSearchIcon />
              </span>
              <input type="text" placeholder="Search Topics"/>
            </div>
            <div className="navmenu-domain">
              <label htmlFor="">Domain List</label>
              <Select options={SelectClient} placeholder="Select" />
            </div>
            <div className="navmenu-domain">
              <label htmlFor="">Sub Domain List</label>
              <Select options={SelectClient} placeholder="Select" />
            </div>
          </div>
          <div className="rght-hdr">
            <div className="hdrmr-main">
              <ProfileDropdown/>
            </div>
          </div>
        </div>
      </topbar>
    </>
  );
}

export default Header;
