import React, { useState } from "react";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import Select from "react-select";

import "react-phone-number-input/style.css";
import { Link } from "react-router-dom";
const index = () => {
  const [value, setValue] = useState();

  const Domain = [
    { value: "Domain", label: "Domain" },
    { value: "Tech", label: "Tech" },
    { value: "Education", label: "Education" },
  ];
  
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>
                        Tell Us More About You
                      </h3>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="form-flex">
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">
                                Occupation
                                </label>
                                <Select
                                  options={Domain}
                                  placeholder="Choose your profession"
                                />
                              </div>
                            </div>
                            <div className="form-inner-flex-50">
                              <div className="form-inputs">
                                <label className="form-label">
                                Age Group
                                </label>
                                <Select
                                  options={Domain}
                                  placeholder="Select your age group"
                                />
                              </div>
                            </div>
                            <div className="form-inner-flex-100">
                              <div className="form-inputs">
                                <label className="form-label">
                                Location
                                </label>
                                <Select
                                  options={Domain}
                                  placeholder="Select your country or city"
                                />
                              </div>
                            </div>
                            <div className="form-inner-flex-100">
                              <label className="form-label">
                                Interests <i>*</i>
                              </label>
                              <div className="interests-list">
                                <ul>
                                    <li>
                                        <div className="interests-field">
                                            <span>Education</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Finance</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Technology</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Food</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Sports</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Health care</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Performing Arts</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Manufacturing</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Legal</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Government service</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Marketing</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Media Arts</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Fashion</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Transportation</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Branding</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Real Estate</span>
                                        </div>
                                    </li>
                                 
                                    <li>
                                        <div className="interests-field">
                                            <span>Social Work</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Retail</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="interests-field">
                                            <span>Aerospace</span>
                                        </div>
                                    </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                          <div className="auth-btn">
                            <Link to="/expert-verification" className="btn btn-primary">Continue</Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
