import React from "react";
import {
  ExpertImage1,
  ExpertImage2,
  ExpertImage3,
  ExpertImage4,
} from "../assets/images";

const FollowerListPopup = ({ handlePopup }) => {
  const followers = [
    {
      avatar: ExpertImage1,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: null,
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Innovator", type: "innovator" },
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Occupational",
      badge: null,
    },
    {
      avatar: ExpertImage4,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Expert", type: "expert" },
    },
    {
      avatar: ExpertImage1,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: { label: "Expert", type: "expert" },
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Epidemiologist",
      badge: { label: "Contributor", type: "contributor" },
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Public Health Officer",
      badge: null,
    },
  ];
  return (
    <>
      <div className="main-popup follower-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="card">
                <div className="card-body">
                  <div className="top-heading">
                    <h3>followers</h3>
                    <span onClick={handlePopup}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        class="bi bi-x-lg"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
                      </svg>
                    </span>
                  </div>
                  <div className="follower-list">
                    {followers.map((follower, index) => (
                      <div key={index} className="follower-card">
                        <img
                          src={follower.avatar}
                          alt={follower.name}
                          className="avatar"
                        />
                        <div className="follower-info">
                          <div className="follower-name">
                            {follower.name}
                            {follower.badge && (
                              <span className={`badge ${follower.badge.type}`}>
                                {follower.badge.label}
                              </span>
                            )}
                          </div>
                          <div className="follower-role">
                            {follower.profession}
                            {/* <span className="follow-link">/ Follow</span> */}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>
    </>
  );
};

export default FollowerListPopup;
