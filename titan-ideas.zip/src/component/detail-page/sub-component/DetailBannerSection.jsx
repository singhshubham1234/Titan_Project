import React from "react";
import { DetailPageImage } from "../../../assets/images";
import {
  SvgFavrateIcon,
  SvgMassageIcon,
  SvgShareIcon,
} from "../../../assets/svg-files/SvgFiles";

const DetailBannerSection = () => {
  return (
    <section className="detailbanner-section">
      <div className="container">
        <div className="detailbanner-image">
          <span style={{ backgroundImage: `url(${DetailPageImage})` }}> </span>
        </div>
        <div className="detailprofile">
          <h3>Sarah Mitchell, </h3>
          <p>CEO, TechBloom</p>
          <div className="detailsocail-list">
            <ul>
              <li>
                <div className="detail-socail">
                  <span>
                    <SvgFavrateIcon />
                  </span>
                  <p>24.5k</p>
                </div>
              </li>
              <li>
                <div className="detail-socail">
                  <span>
                    <SvgMassageIcon />
                  </span>
                  <p>50</p>
                </div>
              </li>
              <li>
                <div className="detail-socail">
                  <span>
                    <SvgShareIcon />
                  </span>
                  <p>20</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DetailBannerSection;
