import React, { useState } from "react";
import { Link } from "react-router-dom";
import Select from "react-select";
import PaymentPopup from "./PaymentPopup";

const SponsoredPopup = ({ handlePopup }) => {
  const Domain = [
    { value: "Domain", label: "Domain" },
    { value: "Tech", label: "Tech" },
    { value: "Education", label: "Education" },
  ];
  const [showPaymentPopup, setPaymentPopup] = useState(false);
  const handlePaymentPopupToggle = () => {
    setPaymentPopup((prev) => !prev);
  };
  return (
    <>
      <div className="main-popup sponsored-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="card">
                <div className="card-body">
                  <div className="top-heading">
                    <h3>Sponsored post form</h3>
                  </div>
                  <div className="sponsored-main">
                    <div className="subscription-toggel">
                      <div className="shareideas-heading">
                        <h4>Target Audience</h4>
                      </div>
                      <div className="expert-toggel">
                        <div class="svcrd-togl me-2">
                          <div class="tgl-sld">
                            <span htmlFor="">Experts Only</span>
                            <label>
                              <input type="checkbox" />
                              <span>
                                <i></i>
                              </span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="form-flex">
                      <div className="form-inner-flex-50">
                        <div className="form-inputs">
                          <label className="form-label">Age Group</label>
                          <Select options={Domain} placeholder="18-20" />
                        </div>
                      </div>
                      <div className="form-inner-flex-50">
                        <div className="form-inputs">
                          <label className="form-label">
                            Post Location Filters
                          </label>
                          <Select options={Domain} placeholder="India" />
                        </div>
                      </div>
                      <div className="form-inner-flex-50">
                        <div className="form-inputs">
                          <label className="form-label">Post Duration</label>
                          <Select
                            options={Domain}
                            placeholder="3 days,  7 days,  15days"
                          />
                        </div>
                      </div>
                      <div className="form-inner-flex-50">
                        <div className="form-inputs">
                          <label className="form-label">
                            Audience Selection
                          </label>
                          <Select
                            options={Domain}
                            placeholder="Audience select"
                          />
                        </div>
                      </div>
                      <div className="form-inner-flex-100">
                        <div className="form-inputs">
                          <label className="form-label">Price</label>
                          <input type="text" placeholder="$500" />
                        </div>
                      </div>
                    </div>
                    <div className="sponsored-btn">
                      <Link
                        to="#"
                        className="btn btn-primary"
                        onClick={handlePaymentPopupToggle}
                      >
                        Continue to payment
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>

      {showPaymentPopup && (
        <PaymentPopup handlePopup={handlePaymentPopupToggle} />
      )}
    </>
  );
};

export default SponsoredPopup;
