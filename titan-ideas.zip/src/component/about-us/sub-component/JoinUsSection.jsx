import React from "react";

const JoinUsSection = () => {
  return (
    <section className="joinus-section">
      <div className="container">
        <div className="joinus-card">
          <div className="joinus-inner-crd">
            <div className="joinus-heading">
              <h5>Join us now</h5>
              <h3>
                Join us in <span>transforming</span> raw ideas into impactful
                innovations.
              </h3>
            </div>
            <div className="joinus-populer-list">
              <div className="joinus-populer">
                <h2>74k+</h2>
                <h5>Impressive Performance</h5>
                <p>Another way to grow fast</p>
              </div>
              <div className="joinus-populer">
                <h2>29%</h2>
                <h5>Customer Retention</h5>
                <p>On your website</p>
              </div>
              <div className="joinus-populer">
                <h2>19%</h2>
                <h5>Extra Growth Revenue</h5>
                <p>From your sales</p>
              </div>
            </div>
            <div className="joinus-btn">
              <button className="btn btn-primary">Join Now</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JoinUsSection;
