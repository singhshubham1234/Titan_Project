import React from "react";
import { Avatar } from "../../../assets/images";
import {
  SvgBasketBallIcon,
  SvgLinkdenIcon,
  SvgTwitterIcon,
} from "../../../assets/svg-files/SvgFiles";
import { Link } from "react-router-dom";

const TeamMeetingsection = () => {
  return (
    <section className="teammeeting-section">
      <div className="container">
        <div className="top-heading">
          <h5>Meet the Team</h5>
          <h3>
            Our dedicated team is here to support you every step of the way.
          </h3>
        </div>
        <div className="teammeeting-list">
          <ul>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="teammeeting-card">
                <div className="teammeeting-image">
                  <img src={Avatar} alt="" />
                </div>
                <div className="teammeeting-description">
                  <h3>Olivia Rhye</h3>
                  <h5>Founder & CEO</h5>
                  <p>
                    Former co-founder of Opendoor. Early staff at Spotify and
                    Clearbit.
                  </p>
                </div>
                <div className="teammeeting-social">
                  <Link to="#">
                    <SvgTwitterIcon />
                  </Link>
                  <Link to="#">
                    <SvgLinkdenIcon />
                  </Link>
                  <Link to="#">
                    <SvgBasketBallIcon />
                  </Link>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default TeamMeetingsection;
