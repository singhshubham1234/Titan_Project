import React from "react";
import { ExpertImage1 } from "../../../assets/images";

const Notification = () => {
  return (
    <div className="notification-main">
      <div className="card">
        <div className="card-body">
          <div className="notification-heading">
            <h3>Notification</h3>
          </div>
          <div className="notification-list">
            <ul>
              <li>
                  <div className="notification-title">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h5>"You have a new message from Admin."</h5>
                    <p>Bender Rodriguez · DesignDrops · Mar 4</p>
                  </div>
              </li>
              <li>
                  <div className="notification-title">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h5>"You have a new message from Admin."</h5>
                    <p>Bender Rodriguez · DesignDrops · Mar 4</p>
                  </div>
              </li>
              <li>
                  <div className="notification-title">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h5>"You have a new message from Admin."</h5>
                    <p>Bender Rodriguez · DesignDrops · Mar 4</p>
                  </div>
              </li>
              <li>
                  <div className="notification-title">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h5>"You have a new message from Admin."</h5>
                    <p>Bender Rodriguez · DesignDrops · Mar 4</p>
                  </div>
              </li>
              <li>
                  <div className="notification-title">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h5>"You have a new message from Admin."</h5>
                    <p>Bender Rodriguez · DesignDrops · Mar 4</p>
                  </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Notification;
