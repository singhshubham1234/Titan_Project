import React from "react";
import { AboutUsBanner } from "../../../assets/images";
import { Link } from "react-router-dom";

const AboutBannerSection = () => {
  return (
    <section
      className="banner-section aboutus-section"
      style={{ backgroundImage: `url(${AboutUsBanner})` }}
    >
      <div className="container">
        <div className="banner-main">
          <div className="banner-heading">
            {/* <h5>Welcome to Titan Ideas</h5> */}
            <h1>
              Empowering <span>Every</span> Idea, <span>Elevating</span> Every
              Vision.
            </h1>
            <p>
              At Titan, we empower visionaries by transforming bold ideas into
              reality through expert validation, seamless execution, and
              cutting-edge technology.{" "}
            </p>
            <div className="banner-btn">
              <Link to="#" className="btn btn-primary">
              Discover More
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutBannerSection;
