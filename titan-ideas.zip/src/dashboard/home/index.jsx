import React from 'react'
import AllPostmain from './sub-component/AllPostmain'

const index = () => {
  return (
    <AllPostmain/>
  )
}

export default index