import React from "react";
import {
  ExpertImage1,
  FeaturedImage1,
  FeaturedImage2,
  FeaturedImage3,
} from "../../../../assets/images";
import {
  SvgDashContributorsIcon,
  SvgDashExpertIcon,
  SvgDashInnovatorIcon,
  SvgDashPremiumIcon,
} from "../../../../assets/svg-files/SvgFiles";

const AllPost = () => {
  const postsData = [
    {
      id: 1,
      expertImage: ExpertImage1,
      username: "John Edward",
      timeAgo: "3 weeks ago",
      images: [FeaturedImage2, FeaturedImage1, FeaturedImage3],
      title: "Medical Service",
      domain: "Medical",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit Lorem ipsum dolor sit amet, consectetur adipiscing elit Lorem ipsum dolor sit amet, consectetur adipiscing elit Lorem ipsum dolor sit amet, consectetur adipiscing elit Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
      stats: {
        reach: 6,
        affordability: 8,
        rationality: 9,
        exclusivity: 7,
        total: 30,
      },
      replies: 80,
      SvgIcon: <SvgDashExpertIcon />,
    },
    {
      id: 1,
      expertImage: ExpertImage1,
      username: "John Edward",
      timeAgo: "3 weeks ago",
      images: [FeaturedImage2, FeaturedImage1, FeaturedImage3],
      title: "Medical Service",
      domain: "Medical",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit ipsum dolor sit amet, consectetur adipiscing elit. ipsum dolor sit amet, consectetur adipiscing elit...",
      stats: {
        reach: 6,
        affordability: 8,
        rationality: 9,
        exclusivity: 7,
        total: 30,
      },
      SvgIcon: <SvgDashContributorsIcon />,
      replies: 80,
    },
    {
      id: 1,
      expertImage: ExpertImage1,
      username: "John Edward",
      timeAgo: "3 weeks ago",
      images: [FeaturedImage2, FeaturedImage1, FeaturedImage3],
      title: "Medical Service",
      domain: "Medical",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit Lorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem ipsum dolor sit amet, consectetur adipiscing elitLorem...",
      stats: {
        reach: 6,
        affordability: 8,
        rationality: 9,
        exclusivity: 7,
        total: 30,
      },
      replies: 80,
      SvgIcon: <SvgDashPremiumIcon />,
    },
    {
      id: 1,
      expertImage: ExpertImage1,
      username: "John Edward",
      timeAgo: "3 weeks ago",
      images: [FeaturedImage2, FeaturedImage1, FeaturedImage3],
      title: "Medical Service",
      domain: "Medical",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
      stats: {
        reach: 6,
        affordability: 8,
        rationality: 9,
        exclusivity: 7,
        total: 30,
      },
      replies: 80,
    },
    {
      id: 1,
      expertImage: ExpertImage1,
      username: "John Edward",
      timeAgo: "3 weeks ago",
      images: [FeaturedImage2, FeaturedImage1, FeaturedImage3],
      title: "Medical Service",
      domain: "Medical",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
      stats: {
        reach: 6,
        affordability: 8,
        rationality: 9,
        exclusivity: 7,
        total: 30,
      },
      replies: 80,
      SvgIcon: <SvgDashInnovatorIcon />,
    },
    // Add 2 more similar post objects with different content or images
  ];

  return (
    <div className="authpost-main">
      {postsData.map((post) => (
        <div className="post" key={post.id}>
          {/* Header */}
          <div className="post-header">
            <div className="post-user">
              <span
                style={{ backgroundImage: `url(${post.expertImage})` }}
                alt="avatar"
              />
              <div className="posttp-title">
                <div className="post-name">
                  <p className="post-username">{post.username}</p>
                  {post.SvgIcon}
                </div>

                <div className="post-weekslist">
                  <p>{post.timeAgo}</p>
                  <em className="post-followlink">Follow</em>
                </div>
              </div>
            </div>
            <div className="post-menu">•••</div>
          </div>

          {/* Image */}
          <div className="grid-imagemain">
            {post.images.map((img, index) => (
              <div
                key={index}
                className={`grid-image item-${index + 1}`}
                style={{ backgroundImage: `url(${img})` }}
              >
                {index === 2 && <div className="overlay">+4</div>}
              </div>
            ))}
          </div>

          {/* Content */}
          <div className="post-content">
            <h3 className="post-title">{post.title}</h3>
            <span className="postdomain-badge">{post.domain}</span>
            <p className="post-description">
              {post.description}
              <span className="post-readmore">Read more</span>
            </p>
          </div>

          {/* Stats */}
          <div className="post-stats">
            <div className="post-stat">
              <strong>Reach:</strong> {post.stats.reach}/10{" "}
              <svg
                width="11"
                height="11"
                viewBox="0 0 11 11"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                  fill="#050505"
                />
              </svg>
            </div>
            <div className="post-stat">
              <strong>Affordability:</strong> {post.stats.affordability}/10{" "}
              <svg
                width="11"
                height="11"
                viewBox="0 0 11 11"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                  fill="#050505"
                />
              </svg>
            </div>
            <div className="post-stat">
              <strong>Rationality:</strong> {post.stats.rationality}/10{" "}
              <svg
                width="11"
                height="11"
                viewBox="0 0 11 11"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                  fill="#050505"
                />
              </svg>
            </div>
            <div className="post-stat">
              <strong>Exclusivity:</strong> {post.stats.exclusivity}/10{" "}
              <svg
                width="11"
                height="11"
                viewBox="0 0 11 11"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                  fill="#050505"
                />
              </svg>
            </div>
            <div className="post-stat post-total">
              <strong>Total:</strong> {post.stats.total}/40{" "}
              <svg
                width="11"
                height="11"
                viewBox="0 0 11 11"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                  fill="#050505"
                />
              </svg>
            </div>
          </div>

          {/* Reply */}
          <div className="replay-icon">
            <span>
              <svg
                width="20"
                height="14"
                viewBox="0 0 20 14"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M19.761 12.2809C19.8839 12.1578 19.964 12.0006 19.9904 11.8313C20.0169 11.6619 19.9882 11.4888 19.9084 11.3359L19.0798 9.75245C18.157 7.98554 16.747 6.50116 15.0065 5.46414C13.266 4.42712 11.2631 3.87805 9.22012 3.87791H8.76216C8.73316 3.26978 8.69575 2.66205 8.64994 2.05489L8.57286 1.02305C8.55853 0.832486 8.49339 0.648794 8.38382 0.489964C8.27425 0.331135 8.12401 0.202614 7.94781 0.116987C7.77161 0.0313599 7.57548 -0.00843811 7.37865 0.00149076C7.18181 0.0114196 6.99101 0.0707349 6.82492 0.173628C4.42658 1.65916 2.34158 3.57333 0.681067 5.81411L0.159633 6.51849C0.0558333 6.6586 0 6.82674 0 6.99924C0 7.17174 0.0558333 7.33989 0.159633 7.48L0.681067 8.18327C2.34147 10.4244 4.42647 12.339 6.82492 13.8249C7.5504 14.2754 8.50938 13.8084 8.57286 12.9754L8.64994 11.9425C8.70435 11.2187 8.74705 10.4935 8.77803 9.76674C11.2531 9.69544 13.7114 10.1826 15.9591 11.1898L18.793 12.4579C18.9532 12.5296 19.1325 12.5512 19.3059 12.5197C19.4794 12.4882 19.6385 12.4051 19.761 12.282M17.2559 9.95465L16.6721 9.69421C13.9275 8.46611 10.9044 7.93916 7.89046 8.16349C7.68118 8.17914 7.48528 8.26929 7.34045 8.41658C7.19563 8.56386 7.11214 8.75788 7.10604 8.96127C7.07733 9.91728 7.02669 10.8718 6.95415 11.8249L6.94735 11.9205C5.06047 10.6296 3.40922 9.04221 2.06173 7.22396L1.89624 6.99869L2.06173 6.77562C3.40913 4.95698 5.06038 3.36926 6.94735 2.07796L6.95415 2.17357C7.01838 3.02482 7.06561 3.87681 7.09584 4.72953C7.1032 4.94331 7.196 5.14595 7.35465 5.29461C7.5133 5.44328 7.72535 5.52633 7.946 5.52621H9.22012C10.8401 5.52618 12.4324 5.9341 13.8408 6.71002C15.2493 7.48594 16.4257 8.60324 17.2547 9.95245"
                  fill="white"
                />
              </svg>
            </span>
            <p>{post.replies} Replies</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AllPost;
