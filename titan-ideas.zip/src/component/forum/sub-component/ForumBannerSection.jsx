import React from "react";
import { AboutUsBanner } from "../../../assets/images";
import { Link } from "react-router-dom";

const ForumBannerSection = () => {
  return (
    <section
      className="banner-section forumbanner-section"
      style={{ backgroundImage: `url(${AboutUsBanner})` }}
    >
      <div className="container">
        <div className="banner-main">
          <div className="banner-heading">
            {/* <h5>Welcome to Titan Ideas</h5> */}
            <h1>
              Explore <span>Forums</span> Across All Industries
            </h1>
            <p>
              From Tech to Healthcare, explore forums tailored to your field and
              connect with innovators like you.
            </p>
            <div className="banner-btn">
              <Link to="#" className="btn btn-primary">
              Explore Domains
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ForumBannerSection;
