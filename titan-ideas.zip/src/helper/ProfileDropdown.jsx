import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ExpertImage1 } from "../assets/images";
import {
  SvgDashboardHrdProfileIcon,
  SvgDashboardLogoutIcon,
} from "../assets/svg-files/SvgFiles";
// import LogOutPopup from "./LogOutPopup";
// import { FeeImage } from "../assets/images";
const ProfileDropdown = () => {
  const navigate = useNavigate();
  const [showProfile, setShowProfile] = useState(false);
  const selectRef = useRef();

  // const goToNext = (path) => {
  //   navigate(path);
  //   setShowProfile(false);
  // };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (selectRef.current && !selectRef.current.contains(event.target)) {
        setShowProfile(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [selectRef]);

  // const [showLogOutPopup, setLogOutPopup] = useState(false);
  // const handleLogOutPopup = () => {
  //   setLogOutPopup((p) => !p);
  // };

  return (
    <>
      <div className="profile-dropdown" ref={selectRef}>
        <div
          className="profile-dropdown-title"
          onClick={() => setShowProfile((p) => !p)}
        >
          <div className="profile-dropdown-bg">
            <span
              style={{
                backgroundImage: `url(${ExpertImage1})`,
              }}
            ></span>
          </div>
          <div className="profile-username">
            <h5>Moni Roy</h5>
            <p>olivia@untitledui.com</p>
          </div>
        </div>
        {showProfile && (
          <div className="profile-dropdown-box">
            <ul>
              <li>
                <Link to="/home/profile">
                  <SvgDashboardHrdProfileIcon />
                  View Profile
                </Link>
              </li>
              <li>
                <Link>
                  <SvgDashboardLogoutIcon />
                  Log Out
                </Link>
              </li>
            </ul>
          </div>
        )}
      </div>

      {/* {showLogOutPopup && <LogOutPopup handlePopup={handleLogOutPopup} />} */}
    </>
  );
};

export default ProfileDropdown;
