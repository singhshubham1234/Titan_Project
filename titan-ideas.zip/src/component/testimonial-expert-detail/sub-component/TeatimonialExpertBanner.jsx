import React from "react";
import { BlogBannerImage, ExpertImage1 } from "../../../assets/images";

const TeatimonialExpertBanner = () => {
  return (
    <div
      className="detail-testmnalexpert"
      style={{ backgroundImage: `url(${BlogBannerImage})` }}
    >
      <div className="container">
        <div className="testmnalexpert-profile">
          <span style={{ backgroundImage: `url(${ExpertImage1})` }}></span>
          <div className="testmnalexpert-title">
            <h3>Priya</h3>
            <p>Lead Designer</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeatimonialExpertBanner;
