import React from "react";

const ChangePasswordTab = () => {
  return (
    <div className="changepassword-main">
      <div className="form-flex">
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">Current password</label>
            <input type="text" placeholder="Your First Name" />
          </div>
        </div>
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">New password</label>
            <input type="text" placeholder="Your last Name" />
          </div>
        </div>
        <div className="form-inner-flex-50">
          <div className="form-inputs">
            <label className="form-label">Repeat new password</label>
            <input type="text" placeholder="xyz@gmail.com" />
          </div>
        </div>
      </div>
      <div className="editprofile-btn">
        <button className="btn btn-info">Cancel</button>
        <button className="btn btn-primary">Update</button>
      </div>
    </div>
  );
};

export default ChangePasswordTab;
