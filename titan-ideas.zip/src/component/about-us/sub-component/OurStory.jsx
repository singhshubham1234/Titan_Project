import React from "react";
import { DoubleIcon, OurStoryImage } from "../../../assets/images";

const OurStory = () => {
  return (
    <section className="ourstory-section">
      <div className="container">
        <div className="top-heading mb-50">
          <h5>OUR STORY</h5>
          <h3>Evolving from dreams to innovation</h3>
        </div>
        <div className="ourstory-descption">
          <div className="main-flex">
            <div className="inner-flex-50">
              <div className="our-story-image">
                <img src={OurStoryImage} alt="" />
              </div>
            </div>
            <div className="inner-flex-50">
              <div className="our-content">
                <p>
                  Every great idea starts with a spark. At Titan Ideas, we
                  provide the platform and community to turn that spark into a
                  flame. By focusing on validation, collaboration, and
                  innovation, we empower individuals to bring their ideas to
                  life, creating a more innovative and inclusive world. Our
                  platform challenges conventional knowledge, fostering an
                  environment where great minds can come together to discuss and
                  develop groundbreaking ideas. After all, great minds talk
                  about ideas.{" "}
                </p>
                <p>
                  We believe in the power of our RARE rating system to guide
                  this process. By evaluating ideas on Reach, Affordability,
                  Rationality, and Exclusivity, we ensure that every idea is
                  thoroughly vetted and has the potential to succeed. The RARE
                  rating system works because it covers all critical aspects of
                  idea validation, helping users refine their concepts and bring
                  them closer to reality.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="ourstory-challenge">
          <ul>
            <li>
              <div className="challenge-card">
                <div className="challenge-heading">
                  <h3>VISION</h3>
                  <span>
                    <img src={DoubleIcon} alt="" />
                  </span>
                </div>
                <p>
                  To be the leading global platform for idea validation and
                  collaboration, transforming raw ideas into impactful
                  innovations.
                </p>
              </div>
            </li>
            <li>
              <div className="challenge-card">
                <div className="challenge-heading">
                  <h3>MISSION</h3>
                  <span>
                    <img src={DoubleIcon} alt="" />
                  </span>
                </div>
                <p>
                  Our mission is to facilitate the growth of raw ideas into
                  successful ventures through expert feedback, community
                  collaboration, and strategic partnerships.
                </p>
              </div>
            </li>
            <li>
              <div className="challenge-card">
                <div className="challenge-heading">
                  <h3>PURPOSE</h3>
                  <span>
                    <img src={DoubleIcon} alt="" />
                  </span>
                </div>
                <p>
                  To empower individuals to share and develop their ideas,
                  fostering a culture of innovation and progress.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default OurStory;
