import React from "react";
import {
  CoreImage1,
  CoreImage2,
  CoreImage3,
  CoreImage4,
  CoreImage5,
} from "../../../assets/images";

const OurCoreSection = () => {
  return (
    <section className="ourcore-section">
      <div className="container">
        <div className="top-heading">
          <h5>OUR CORE VALUES</h5>
          <h3>
            Innovation with Purpose, Growth with Integrity, and Success with
            Impact.
          </h3>
        </div>
        <div className="ourcore-list">
          <ul>
            <li>
              <div className="ourcore-crd">
                <div className="ourcore-image">
                  <img src={CoreImage1} alt="" />
                </div>
                <h4>Integrity</h4>
                <p>Ensuring honesty and transparency in all interactions.</p>
              </div>
            </li>
            <li>
              <div className="ourcore-crd">
                <div className="ourcore-image">
                  <img src={CoreImage2} alt="" />
                </div>
                <h4>Collaboration</h4>
                <p>Fostering teamwork and partnerships</p>
              </div>
            </li>
            <li>
              <div className="ourcore-crd">
                <div className="ourcore-image">
                  <img src={CoreImage3} alt="" />
                </div>
                <h4>Inclusivity</h4>
                <p>A forum for everyone to share ideas.</p>
              </div>
            </li>
            <li>
              <div className="ourcore-crd">
                <div className="ourcore-image">
                  <img src={CoreImage4} alt="" />
                </div>
                <h4>Innovation</h4>
                <p>Encouraging creative thinking and new ideas.</p>
              </div>
            </li>
            <li>
              <div className="ourcore-crd">
                <div className="ourcore-image">
                  <img src={CoreImage5} alt="" />
                </div>
                <h4>Empowerment</h4>
                <p>
                  Providing tools and support for users to achieve their goals.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default OurCoreSection;
