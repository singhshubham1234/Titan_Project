import React, { useState } from "react";

const MediaUploader = () => {
  const [files, setFiles] = useState([]);

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles(Array.from(e.dataTransfer.files));
  };

  const handleChange = (e) => {
    setFiles(Array.from(e.target.files));
  };

  const preventDefaults = (e) => e.preventDefault();

  return (
    <div
      className="uploader"
      onClick={() => document.getElementById("fileInput").click()}
      onDrop={handleDrop}
      onDragOver={preventDefaults}
      onDragEnter={preventDefaults}
    >
      <input
        type="file"
        id="fileInput"
        accept="image/*,video/*,audio/*"
        multiple
        onChange={handleChange}
      />
      <p>
        <span className="icon">
          <svg
            width="17"
            height="17"
            viewBox="0 0 17 17"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M8.49974 11.6831C8.20518 11.6831 7.96641 11.4443 7.96641 11.1497V9.28307H6.09974C5.80518 9.28307 5.56641 9.0443 5.56641 8.74974C5.56641 8.45518 5.80518 8.21641 6.09974 8.21641H7.96641V6.34974C7.96641 6.05518 8.20518 5.81641 8.49974 5.81641C8.7943 5.81641 9.03307 6.05518 9.03307 6.34974V8.21641H10.8997C11.1943 8.21641 11.4331 8.45518 11.4331 8.74974C11.4331 9.0443 11.1943 9.28307 10.8997 9.28307H9.03307V11.1497C9.03307 11.4443 8.7943 11.6831 8.49974 11.6831Z"
              fill="#6D7280"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M4.76667 0.75C2.41025 0.75 0.5 2.66025 0.5 5.01667V12.4833C0.5 14.8398 2.41025 16.75 4.76667 16.75H12.2333C14.5898 16.75 16.5 14.8398 16.5 12.4833V5.71195C16.5 5.12064 16.2546 4.55584 15.8223 4.15237L12.7916 1.32375C12.3966 0.955053 11.8764 0.75 11.336 0.75H4.76667ZM1.56667 5.01667C1.56667 3.24936 2.99936 1.81667 4.76667 1.81667H11.1667V3.41667C11.1667 4.59488 12.1218 5.55 13.3 5.55H15.421C15.4291 5.60325 15.4333 5.65739 15.4333 5.71195V12.4833C15.4333 14.2506 14.0006 15.6833 12.2333 15.6833H4.76667C2.99936 15.6833 1.56667 14.2506 1.56667 12.4833V5.01667ZM12.2333 3.41667V2.26176L14.6136 4.48333H13.3C12.7109 4.48333 12.2333 4.00576 12.2333 3.41667Z"
              fill="#6D7280"
            />
          </svg>
        </span>
        Upload Image, Video, Audio
      </p>

      {files.length > 0 && (
        <div className="file-list">
          {files.map((file, i) => (
            <div key={i}>{file.name}</div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MediaUploader;
