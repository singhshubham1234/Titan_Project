import React from "react";
import { Link } from "react-router-dom";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import {
  SvgGoogleIcon,
  SvgAppleIcon,
  SvgDashAttchaIcon,
} from "../../../assets/svg-files/SvgFiles";
const index = () => {
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>
                        Verification for Expert
                      </h3>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="form-flex">
                            <div className="form-inner-flex-100">
                              <label className="form-label">
                                Certificate If Any
                              </label>
                              <div className="input-wthicon">
                                <input
                                  type="password"
                                  placeholder="Enter Your Password"
                                />
                                <div className="input-icon">
                                  <span>
                                    <SvgDashAttchaIcon />
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="form-inner-flex-100">
                              <label className="form-label">
                                Linkedin Link
                              </label>
                              <input type="num" placeholder="htpp.@sdisdvnoKMV" />
                            </div>
                            <div className="form-inner-flex-100">
                              <label className="form-label">Github</label>
                              <input type="num" placeholder="htpp.@sdisdvnoKMV" />
                            </div>
                            <div className="form-inner-flex-100">
                              <label className="form-label">
                                Portfolio Link
                              </label>
                              <input type="num" placeholder="htpp.@sdisdvnoKMV" />
                            </div>
                          </div>
                          <div className="auth-btn">
                            <Link
                              to="/verification-success"
                              className="btn btn-primary"
                            >
                              Continue
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
