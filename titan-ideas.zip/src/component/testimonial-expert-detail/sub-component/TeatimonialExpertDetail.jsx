import React from "react";
import {
  SvgFavrateIcon,
  SvgMassageIcon,
  SvgShareIcon,
  SvgStarSmallIcon,
} from "../../../assets/svg-files/SvgFiles";
import { ExpertImage1, ExpertProfile } from "../../../assets/images";
import { Link } from "react-router-dom";

const TeatimonialExpertDetail = () => {
  const expertData = Array.from({ length: 3 }, (_, i) => ({
    id: i + 1,
    title: "It was a very good experience",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eu rhoncus urna facilisis quisque orci lectus sed nulla. amet, consectetur adipiscing Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eu rhoncus urna facilisis quisque orci lectus sed nulla. amet, consectetur adipiscing",
    image: ExpertProfile,
  }));


    const testimonials = [
      {
        name: "Ankit",
        role: "Lead Designer",
        rating: "30/40",
        image: ExpertImage1,
        title: "It was a very good experience",
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
        eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
        felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
        pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
      },
      {
        name: "Ankit",
        role: "Lead Designer",
        rating: "30/40",
        image: ExpertImage1,
        title: "It was a very good experience",
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
        eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
        felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
        pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
      },
      {
        name: "Ankit",
        role: "Lead Designer",
        rating: "30/40",
        image: ExpertImage1,
        title: "It was a very good experience",
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna 
        eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis 
        felis id augue sit cursus pellentesque enim arcu. Elementum felis magna 
        pretium in tincidunt. Suspendisse sed magna eget nibh in turpis.`,
      },
      
      // Add more objects here...
    ];
  return (
    <>
      <div className="teatimonialExpertDetail">
        <div className="container">
          <div className="detailprofile">
            <div className="detailsocail-list">
              <ul>
                <li>
                  <div className="detail-socail">
                    <span>
                      <SvgFavrateIcon />
                    </span>
                    <p>24.5k</p>
                  </div>
                </li>
                <li>
                  <div className="detail-socail">
                    <span>
                      <SvgMassageIcon />
                    </span>
                    <p>50</p>
                  </div>
                </li>
                <li>
                  <div className="detail-socail">
                    <span>
                      <SvgShareIcon />
                    </span>
                    <p>20</p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="post-stats">
              <div className="post-stat">
                <strong>Reach:</strong> 9/10{" "}
                <svg
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                    fill="#050505"
                  />
                </svg>
              </div>
              <div className="post-stat">
                <strong>Affordability:</strong> 5/10{" "}
                <svg
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                    fill="#050505"
                  />
                </svg>
              </div>
              <div className="post-stat">
                <strong>Rationality:</strong> 2/10{" "}
                <svg
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                    fill="#050505"
                  />
                </svg>
              </div>
              <div className="post-stat">
                <strong>Exclusivity:</strong> 6/10{" "}
                <svg
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                    fill="#050505"
                  />
                </svg>
              </div>
              <div className="post-stat post-total">
                <strong>Total:</strong> 36/40{" "}
                <svg
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.50561 10.7304L3.35273 7.10071L0.536041 4.66044L4.24631 4.33936L5.6994 0.916016L7.15249 4.33867L10.8621 4.65976L8.04539 7.10003L8.8932 10.7297L5.6994 8.80316L2.50561 10.7304Z"
                    fill="#050505"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="detail-description">
            <h3>Meet Amelia Bennett, CEO of 'TechBloom'</h3>
            <p>
              Since its inception, TechBloom has experienced rapid growth,
              serving over a hundred major clients across various sectors. The
              company's revenue has increased by 250% in the last three years,
              and they've received multiple awards for innovation and
              sustainability. TechBloom is also committed to community
              engagement, regularly hosting workshops and contributing to
              environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives. Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.Since its inception, TechBloom has
              experienced rapid growth, serving over a hundred major clients
              across various sectors. The company's revenue has increased by
              250% in the last three years, and they've received multiple awards
              for innovation and sustainability. TechBloom is also committed to
              community engagement, regularly hosting workshops and contributing
              to environmental initiatives.
            </p>
          </div>
          <div className="expertlist-list">
            <ul>
              {expertData.map((item) => (
                <li key={item.id}>
                  <Link to="#" className="expertlist-card">
                    <div className="expertlist-description">
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                      <div className="expertlist-arrow"></div>
                    </div>
                    <div className="expertlist-image">
                      <span
                        style={{ backgroundImage: `url(${item.image})` }}
                      ></span>
                      <h3>Lucky</h3>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="usertestimonial-list">
            <ul>
              {testimonials.map((item, index) => (
                <li key={index}>
                  <div className="usertestimonial-card">
                    <div className="usertestimonial-profilerating">
                      <div className="usertestimonial-profile">
                        <span
                          style={{ backgroundImage: `url(${item.image})` }}
                        ></span>
                        <h4>{item.name}</h4>
                        <p>{item.role}</p>
                      </div>
                      <div className="usertestimonial-rating">
                        <p>
                          Rating:{item.rating} <SvgStarSmallIcon />
                        </p>
                      </div>
                    </div>
                    <div className="usertestimonial-description">
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                      <Link to="/detail"  className="read-more">
                        Read more
                      </Link>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default TeatimonialExpertDetail;
