import React, { useState } from "react";
import {
  ExpertImage1 as ExpertImage1Default,
  ProfileBackgroundImage,
} from "../../assets/images"; // make sure these are valid imports
import EditProfileTab from "./editprofile-popuptab/EditProfileTab";
import ChangePasswordTab from "./editprofile-popuptab/ChangePasswordTab";

const EditProfilePopup = ({ handlePopup }) => {
  const [profileImage, setProfileImage] = useState(ExpertImage1Default);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file));
    }
  };
  const [EditProfileActiveTab, setEditProfileActiveTab] = useState(0);

  const EditProfiletabs = [
    { title: "Edit Profile", content: <EditProfileTab /> },
    {
      title: "Change Password",
      content: <ChangePasswordTab />,
    },
  ];
  return (
    <div className="main-popup editprofile-popup">
      <div className="lm-outer">
        <div className="lm-inner">
          <div className="popup-inner">
            <div className="card">
              <div className="editprofile-main">
                <div
                  className="editprofile-bg"
                  style={{
                    backgroundImage: `url(${ProfileBackgroundImage})`,
                  }}
                >
                  <div className="profile-pic-wrapper">
                    <img
                      src={profileImage}
                      alt="Profile"
                      className="profile-pic"
                    />
                    <label htmlFor="profile-upload" className="edit-icon">
                      <i className="fa fa-camera"></i>
                    </label>
                    <input
                      type="file"
                      id="profile-upload"
                      accept="image/*"
                      onChange={handleImageChange}
                      style={{ display: "none" }}
                    />
                  </div>
                  <div className="editcoverpage-icon">
                    <button className="edit-btn">
                      <span>
                        <svg
                          width="15"
                          height="15"
                          viewBox="0 0 15 15"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5.67267 6.16667C6.23305 6.16667 6.78084 6.0005 7.24678 5.68917C7.71272 5.37783 8.07588 4.93533 8.29033 4.4176C8.50477 3.89988 8.56088 3.33019 8.45156 2.78058C8.34223 2.23097 8.07238 1.72611 7.67614 1.32987C7.27989 0.933617 6.77504 0.663768 6.22542 0.554443C5.67581 0.445118 5.10612 0.501228 4.5884 0.715676C4.07067 0.930124 3.62817 1.29328 3.31684 1.75922C3.00551 2.22516 2.83933 2.77295 2.83933 3.33333C2.84022 4.08451 3.13901 4.80467 3.67017 5.33583C4.20133 5.86699 4.92149 6.16579 5.67267 6.16667ZM5.67267 1.5C6.03527 1.5 6.38972 1.60752 6.69121 1.80897C6.9927 2.01042 7.22768 2.29675 7.36645 2.63175C7.50521 2.96675 7.54151 3.33537 7.47077 3.691C7.40003 4.04663 7.22543 4.3733 6.96903 4.6297C6.71263 4.88609 6.38596 5.0607 6.03033 5.13144C5.6747 5.20218 5.30608 5.16587 4.97108 5.02711C4.63608 4.88835 4.34976 4.65337 4.14831 4.35188C3.94686 4.05039 3.83933 3.69593 3.83933 3.33333C3.83986 2.84727 4.03319 2.38126 4.37689 2.03756C4.72059 1.69386 5.1866 1.50053 5.67267 1.5ZM1.5 11.0133C1.5 12.0553 1.94867 12.5 3 12.5H5.66667C5.79927 12.5 5.92645 12.5527 6.02022 12.6464C6.11399 12.7402 6.16667 12.8674 6.16667 13C6.16667 13.1326 6.11399 13.2598 6.02022 13.3536C5.92645 13.4473 5.79927 13.5 5.66667 13.5H3C1.388 13.5 0.5 12.6167 0.5 11.0133C0.5 9.23867 1.504 7.16667 4.33333 7.16667H7C7.51372 7.1577 8.0249 7.24079 8.50933 7.412C8.62425 7.46489 8.71484 7.55936 8.76287 7.67639C8.81089 7.79341 8.81278 7.92429 8.76814 8.04265C8.7235 8.16101 8.63566 8.25805 8.52231 8.31422C8.40897 8.37039 8.27855 8.38151 8.15733 8.34533C7.78527 8.21733 7.39334 8.15682 7 8.16667H4.33333C3.95262 8.13733 3.57008 8.19095 3.21211 8.32382C2.85413 8.4567 2.52925 8.66566 2.25988 8.9363C1.99052 9.20693 1.78308 9.53279 1.65189 9.89138C1.5207 10.25 1.46888 10.6328 1.5 11.0133ZM13.8247 8.25067L13.082 7.50867C12.9741 7.39984 12.8456 7.31356 12.704 7.25485C12.5624 7.19613 12.4106 7.16616 12.2573 7.16667C12.1039 7.16636 11.9519 7.19655 11.8102 7.25549C11.6685 7.31443 11.54 7.40094 11.432 7.51L7.314 11.6473C7.26761 11.6936 7.23083 11.7486 7.20577 11.8091C7.18071 11.8696 7.16788 11.9345 7.168 12V13.6667C7.168 13.7993 7.22068 13.9265 7.31445 14.0202C7.40822 14.114 7.53539 14.1667 7.668 14.1667H9.33467C9.46677 14.1665 9.59348 14.1143 9.68733 14.0213L13.8207 9.90267C13.9295 9.79438 14.0158 9.66567 14.0747 9.52392C14.1336 9.38217 14.164 9.23018 14.164 9.07667C14.164 8.92316 14.1336 8.77117 14.0747 8.62942C14.0158 8.48767 13.9295 8.35895 13.8207 8.25067H13.8247ZM9.12667 13.1667H8.16667V12.2067L10.9147 9.446L11.8873 10.4187L9.12667 13.1667ZM13.1173 9.194L12.596 9.71334L11.6207 8.73734L12.14 8.21533C12.1554 8.19986 12.1736 8.18759 12.1938 8.17923C12.2139 8.17088 12.2355 8.16661 12.2573 8.16667C12.3015 8.16673 12.3439 8.18422 12.3753 8.21533L13.118 8.958C13.1336 8.9733 13.1459 8.99156 13.1543 9.01172C13.1626 9.03188 13.1668 9.05351 13.1667 9.07533C13.1667 9.09739 13.1624 9.11924 13.1539 9.13961C13.1454 9.15998 13.133 9.17847 13.1173 9.194Z"
                            fill="white"
                          />
                        </svg>
                      </span>
                    </button>
                  </div>
                </div>
                <div className="card-body"></div>
              </div>
              <div className="card-body">
                <div className="editprofile-tab">
                  <ul>
                    {EditProfiletabs.map((EditProfiletab, index) => (
                      <li
                        key={index}
                        onClick={() => setEditProfileActiveTab(index)}
                      >
                        <div
                          className={`prfl-title ${
                            index == EditProfileActiveTab
                              ? "EditProfileactive"
                              : ""
                          }`}
                        >
                          <span className="tab-title">
                            {EditProfiletab.title}
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="user-table-detail">
                  <div className="tab-content">
                    {EditProfiletabs[EditProfileActiveTab].content}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="popup-overlay" onClick={handlePopup}></div>
    </div>
  );
};

export default EditProfilePopup;
