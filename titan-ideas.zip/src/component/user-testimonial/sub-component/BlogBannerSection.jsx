import React from "react";
import { BlogBannerImage } from "../../../assets/images";
import { SvgSearchIcon } from "../../../assets/svg-files/SvgFiles";

const BlogBannerSection = () => {
  return (
    <section
      className="blogbanner-section"
      style={{ backgroundImage: `url(${BlogBannerImage})` }}
    >
      <div className="container">
        <div className="banner-heading">
          <h1>
            Explore the <span>Future</span> story with titan
          </h1>
          <p>Success stories of users who have benefitted from Titan Ideas</p>
          <div className="authsearch-field">
          <input type="text" name="" id="" placeholder="Search Topics" />
          <span>
            <SvgSearchIcon />
          </span>
        </div>
        </div>
    
      </div>
    </section>
  );
};

export default BlogBannerSection;
