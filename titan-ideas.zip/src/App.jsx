import React from "react";
import { useRoutes } from "react-router-dom";
import {
  AboutUsPage,
  BlogListPage,
  BlogPage,
  ContactPage,
  DetailPage,
  ExpertPage,
  ExpertVerification,
  ForumPage,
  HomePage,
  LoginPage,
  NewPasswordPage,
  NotificationPage,
  OtpPasswordPage,
  PaymentPage,
  PostPage,
  ProfilePage,
  ResetPasswordPage,
  SignInPage,
  SubscriptionPage,
  SuccessPage,
  TellUsPage,
  TestimonialExpertDetailPage,
  UserTestimonialPage,
  VerificationSuccessPage,
} from "./RoutesMain";

import ScrollToTop from "./helper/ScrollToTop";
import { Footer, Header } from "./component/common";
import DashboardHeader from "./dashboard/common/header/Header";
import SideBar from "./dashboard/common/sidebar/SideBar";
import { Route, Routes } from "react-router-dom";

// Dashboard Layout
const DashboardLayout = () => (
  <div className="dashboard-container">
    <div className="grid-container">
      <DashboardHeader />
      <SideBar />
      <main className="main-dashboard">
        <ScrollToTop />
        <Routes>
          <Route index element={<PostPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route index element={<HomePage />} />
          <Route path="about-us" element={<AboutUsPage />} />
          <Route path="blog" element={<BlogPage />} />
          <Route path="blog-list" element={<BlogListPage />} />
          <Route path="user-testimonial" element={<UserTestimonialPage />} />
          <Route path="forum" element={<ForumPage />} />
          <Route path="expert" element={<ExpertPage />} />
          <Route path="detail" element={<DetailPage />} />
          <Route path="subscription" element={<SubscriptionPage />} />
          <Route path="payment" element={<PaymentPage />} />
          <Route path="notification" element={<NotificationPage />} />
        </Routes>
      </main>
    </div>
  </div>
);

// Main Site Layout
const MainLayout = () => (
  <>
    <Header />
    <ScrollToTop />
    <main className="main">
      <Routes>
        <Route index element={<HomePage />} />
        <Route path="about-us" element={<AboutUsPage />} />
        <Route path="blog" element={<BlogPage />} />
        <Route path="blog-list" element={<BlogListPage />} />
        <Route path="user-testimonial" element={<UserTestimonialPage />} />
        <Route path="detail" element={<TestimonialExpertDetailPage />} />
        <Route path="forum" element={<ForumPage />} />
        <Route path="expert" element={<ExpertPage />} />
        <Route path="blog-detail" element={<DetailPage />} />
        <Route path="contact" element={<ContactPage />} />
      </Routes>
    </main>
    <Footer />
  </>
);

const App = () => {
  const routes = useRoutes([
    { path: "/sign-up", element: <SignInPage /> },
    { path: "/login", element: <LoginPage /> },
    { path: "/tell-us", element: <TellUsPage /> },
    { path: "/expert-verification", element: <ExpertVerification /> },
    { path: "/reset-password", element: <ResetPasswordPage /> },
    { path: "/otp-password", element: <OtpPasswordPage /> },
    { path: "/new-password", element: <NewPasswordPage /> },
    { path: "/success", element: <SuccessPage /> },
    { path: "/verification-success", element: <VerificationSuccessPage /> },
    {
      path: "/home/*",
      element: <DashboardLayout />,
    },
    {
      path: "/*",
      element: <MainLayout />,
    },
  ]);

  return <>{routes}</>;
};

export default App;
