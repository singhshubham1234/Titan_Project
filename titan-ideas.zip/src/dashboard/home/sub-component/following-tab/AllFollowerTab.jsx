import React from "react";
import {
  ExpertImage1,
  ExpertImage2,
  ExpertImage3,
  ExpertImage4,
} from "../../../../assets/images";
import {
  SvgDashContributorsIcon,
  SvgDashExpertIcon,
  SvgDashInnovatorIcon,
  SvgDashPremiumIcon,
} from "../../../../assets/svg-files/SvgFiles";

const AllFollowerTab = () => {
  const followers = [
    {
      avatar: ExpertImage1,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: null,
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: <SvgDashExpertIcon />,
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Occupational",
      badge: null,
    },
    {
      avatar: ExpertImage4,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: <SvgDashPremiumIcon />,
    },
    {
      avatar: ExpertImage1,
      name: "Cameron Williamson",
      profession: "Physiotherapist",
      badge: <SvgDashExpertIcon />,
    },
    {
      avatar: ExpertImage2,
      name: "Cameron Williamson",
      profession: "Epidemiologist",
      badge: <SvgDashContributorsIcon />,
    },
    {
      avatar: ExpertImage3,
      name: "Cameron Williamson",
      profession: "Public Health Officer",
      badge: <SvgDashInnovatorIcon />,
    },
  ];

  return (
    <div className="follower-list">
      {followers.map((follower, index) => (
        <div key={index} className="follower-card">
          <img src={follower.avatar} alt={follower.name} className="avatar" />
          <div className="follower-info">
            <div className="follower-name">
              {follower.name}
              {follower.badge && (
                <span className="badge ">{follower.badge}</span>
              )}
            </div>
            <div className="follower-role">
              {follower.profession}{" "}
              <span className="follow-link">/ Follow</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};


export default AllFollowerTab;
