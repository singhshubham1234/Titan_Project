import React from "react";
import { Link } from "react-router-dom";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import {
  SvgGoogleIcon,
  SvgAppleIcon,
} from "../../../assets/svg-files/SvgFiles";
const index = () => {
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>
                        Congratulations
                      </h3>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="auth-success-main">
                            <span>
                              <svg
                                width="155"
                                height="155"
                                viewBox="0 0 155 155"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M115.596 48.6457C117.888 50.9284 117.896 54.6369 115.613 56.9289L66.2607 106.482C63.978 108.774 60.2696 108.782 57.9776 106.499L39.979 88.575C37.6869 86.2924 37.6792 82.5839 39.9618 80.2918C42.2444 77.9997 45.9529 77.992 48.245 80.2746L62.0936 94.0657L107.313 48.6625C109.596 46.3705 113.304 46.363 115.596 48.6457Z"
                                  fill="#D7B434"
                                />
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M77.1586 12.2143C46.1114 12.2143 20.065 33.8937 13.379 62.9361L13.379 62.9362C12.2906 67.6635 11.7143 72.5909 11.7143 77.6586C11.7143 113.775 41.0421 143.103 77.1586 143.103C113.275 143.103 142.603 113.775 142.603 77.6586C142.603 41.5421 113.275 12.2143 77.1586 12.2143ZM1.96331 60.308C9.8455 26.0697 40.53 0.5 77.1586 0.5C119.745 0.5 154.317 35.0725 154.317 77.6586C154.317 120.245 119.745 154.817 77.1586 154.817C34.5725 154.817 0 120.245 0 77.6586C0 71.6999 0.677961 65.8909 1.96331 60.308Z"
                                  fill="#D7B434"
                                />
                              </svg>
                            </span>
                            <h3>Successfully</h3>
                            <p>Your password has been reset successfully</p>
                          </div>
                          <div className="auth-btn">
                            <Link to="/" className="btn btn-primary">
                              Continue
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
