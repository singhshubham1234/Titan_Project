import React from "react";
import TeatimonialExpertBanner from "./sub-component/TeatimonialExpertBanner";
import TeatimonialExpertDetail from "./sub-component/TeatimonialExpertDetail";

const index = () => {
  return (
    <>
      <TeatimonialExpertBanner />
      <TeatimonialExpertDetail />
    </>
  );
};

export default index;
