import React from "react";
import {
  AboutUsBannerSection,
  HowItWork,
  JoinUsSection,
  OurCoreSection,
  OurStorySection,
  TeamMeetingSection,
} from "./sub-component";

const Index = () => {
  return (
    <>
      <AboutUsBannerSection />
      <OurStorySection />
      <OurCoreSection />
      <HowItWork />
      <TeamMeetingSection />
      <JoinUsSection/>
    </>
  );
};

export default Index;
