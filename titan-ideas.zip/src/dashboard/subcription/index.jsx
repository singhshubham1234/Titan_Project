import React from "react";
import SubcriptionPlan from "./sub-component/SubcriptionPlan";

const index = () => {
  return (
    <>
      <SubcriptionPlan />
    </>
  );
};

export default index;
