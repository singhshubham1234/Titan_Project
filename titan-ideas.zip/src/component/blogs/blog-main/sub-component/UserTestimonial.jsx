import React, { useState } from "react";

import { Link } from "react-router-dom";
import { ExpertImage1, ExpertImage2 } from "../../../../assets/images";
import {
  SvgDegreeLongArrowIcon,
  SvgStarSmallIcon,
} from "../../../../assets/svg-files/SvgFiles";

const UserTestimonial = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleReadMore = () => {
    setIsExpanded((prev) => !prev);
  };

  return (
    <section className="usertestimonial-section">
      <div className="container">
        <div className="top-heading">
          <h3>User Testimonial</h3>
        </div>
        <div className="usertestimonial-list">
          <ul>
            <li>
              <div className="usertestimonial-card">
                <div className="usertestimonial-profilerating">
                  <div className="usertestimonial-profile">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h4>Ankit</h4>
                    <p>Lead Designer</p>
                  </div>
                  <div className="usertestimonial-rating">
                    <p>
                      Rating:30/40 <SvgStarSmallIcon />
                    </p>
                  </div>
                </div>
                <div className="usertestimonial-description">
                  <h3>It was a very good experience</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cursus nibh mauris, nec turpis orci lectus maecenas.
                    Suspendisse sed magna eget nibh in turpis. Consequat duis
                    diam lacus arcu. Faucibus venenatis felis id augue sit
                    cursus pellentesque enim arcu. Elementum felis magna pretium
                    in tincidunt. Suspendisse sed magna eget nibh in turpis.
                  </p>
                  <Link to="/detail" className="read-more">
                    Read more
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="usertestimonial-card">
                <div className="usertestimonial-profilerating">
                  <div className="usertestimonial-profile">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage1})` }}
                    ></span>
                    <h4>Ankit</h4>
                    <p>Lead Designer</p>
                  </div>
                  <div className="usertestimonial-rating">
                    <p>
                      Rating:30/40 <SvgStarSmallIcon />
                    </p>
                  </div>
                </div>
                <div className="usertestimonial-description">
                  <h3>It was a very good experience</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cursus nibh mauris, nec turpis orci lectus maecenas.
                    Suspendisse sed magna eget nibh in turpis. Consequat duis
                    diam lacus arcu. Faucibus venenatis felis id augue sit
                    cursus pellentesque enim arcu. Elementum felis magna pretium
                    in tincidunt. Suspendisse sed magna eget nibh in turpis.
                  </p>
                  <Link to="/detail" className="read-more">
                    Read more
                  </Link>
                </div>
              </div>
            </li>
            <li>
              <div className="usertestimonial-card">
                <div className="usertestimonial-profilerating">
                  <div className="usertestimonial-profile">
                    <span
                      style={{ backgroundImage: `url(${ExpertImage2})` }}
                    ></span>
                    <h4>Ankit</h4>
                    <p>Lead Designer</p>
                  </div>
                  <div className="usertestimonial-rating">
                    <p>
                      Rating:30/40 <SvgStarSmallIcon />
                    </p>
                  </div>
                </div>
                <div className="usertestimonial-description">
                  <h3>It was a very good experience</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cursus nibh mauris, nec turpis orci lectus maecenas.
                    Suspendisse sed magna eget nibh in turpis. Consequat duis
                    diam lacus arcu. Faucibus venenatis felis id augue sit
                    cursus pellentesque enim arcu. Elementum felis magna pretium
                    in tincidunt. Suspendisse sed magna eget nibh in turpis.
                  </p>
                  <Link to="/detail" className="read-more">
                    Read more
                  </Link>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="featured-viewsbtn">
          <Link to="/user-testimonial">
            View All
            <span>
              <SvgDegreeLongArrowIcon />
            </span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default UserTestimonial;
