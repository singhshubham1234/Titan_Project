import React, { useState } from "react";
import {
  Experts1,
  Experts2,
  Experts3,
  Experts4,
  Experts5,
} from "../../../assets/images";
import {
  SvgDegreeLongArrowIcon,
  SvgPasueIcon,
  SvgPlayIcon,
} from "../../../assets/svg-files/SvgFiles";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from "react-router-dom";
const ExpertsTrust = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    centerMode: true,
    centerPadding: "160px",
    beforeChange: (oldIndex, newIndex) => {
      setCurrentSlide(newIndex);
    },
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          centerPadding: "40px",
        },
      },
    ],
  };

  const experts = [
    {
      id: 1,
      name: "Albert Flores",
      role: "Founder of GearUp",
      image: Experts1,
    },
    { id: 2, name: "Jenny Wilson", role: "CEO of TechCorp", image: Experts2 },
    {
      id: 3,
      name: "Cameron Williamson",
      role: "Marketing Head",
      image: Experts3,
    },
    { id: 4, name: "Dianne Russell", role: "Design Expert", image: Experts4 },
    {
      id: 5,
      name: "Kristin Watson",
      role: "Business Analyst",
      image: Experts5,
    },
  ];
  return (
    <section className="experts-section">
      <div className="top-heading mb-50">
        <h5>Experts You Trust</h5>
        <h3>Meet the Experts Behind Innovation</h3>
      </div>
      <Slider {...settings} className="expert-slider">
        {experts.map((expert, index) => {
          let className = "expert-card";
          if (index === currentSlide) {
            className += " center-image";
          } else if (index === currentSlide - 1 || index === currentSlide + 1) {
            className += " onther-image";
          }

          return (
            <div key={expert.id} className={className}>
              <div className="expert-image">
                <img src={expert.image} alt="" />
              </div>
              <div className="experts-content">
                <div className="expert-descp">
                  <h5>{expert.name}</h5>
                  <p>{expert.role}</p>
                </div>
                <div className="expert-playicon">
                  <span>
                    <SvgPlayIcon />
                    <SvgPasueIcon />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </Slider>
      <div className="featured-viewsbtn">
        <Link to="/blog">
          View All
          <span>
            <SvgDegreeLongArrowIcon />
          </span>
        </Link>
      </div>
    </section>
  );
};

export default ExpertsTrust;
