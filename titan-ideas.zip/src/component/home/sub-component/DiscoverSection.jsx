import React from "react";
import {
  DiscEducation,
  DiscFinance,
  Dischealth,
  DiscMarking,
  DiscTechnology,
} from "../../../assets/images";
import { Link } from "react-router-dom";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

const DiscoverSection = () => {
  const discoverData = [
    { image: DiscEducation, title: "Education" },
    { image: DiscFinance, title: "Finance" },
    { image: DiscTechnology, title: "Technology" },
    { image: DiscMarking, title: "Marketing" },
    { image: Dischealth, title: "Health Care" },
  ];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 5, // Change based on your design
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <section className="discover-section">
      <div className="container">
        <div className="top-heading">
          <h5>Discover our forums</h5>
          <h3>Explore our Diverse Industry Domains</h3>
        </div>
      </div>
      <div className="discover-main">
        <div className="container">
          <div className="discover-list">
            <Slider {...settings}>
              {discoverData.map((item, index) => (
                <div key={index}>
                  <Link to="/home" className="discover-card">
                    <div className="disc-image">
                      <img src={item.image} alt={item.title} />
                    </div>
                    <h4>{item.title}</h4>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua.
                    </p>
                  </Link>
                </div>
              ))}
            </Slider>
          </div>
          <div className="discover-btn">
            <Link to="/forum" className="btn btn-primary">
              View All
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiscoverSection;
