import React, { useState } from "react";
import { Link } from "react-router-dom";
import SubscriptionPopup from "./SubscriptionPopup";

const WarningPopup = ({ handlePopup }) => {
  const [showSubscriptionPopup, setSubscriptionPopup] = useState(false);
  const handleSubscriptionPopupToggle = () => {
    setSubscriptionPopup((prev) => !prev);
  };
  return (
    <>
      <div className="main-popup warning-popup">
        <div className="lm-outer">
          <div className="lm-inner">
            <div className="popup-inner">
              <div className="card-body">
                <div className="popup-heading">
                  <h3>Warning</h3>
                  <p>
                    Your Idea Will Be Public (Unprotected) And Visible To
                    Everyone. Do You Want To Submit It For Free?"
                  </p>
                </div>
                <div className="popupwarning-btn">
                  <button className="btn btn-info">
                    Yes, Continue For Free
                  </button>
                  <Link
                    className="btn btn-primary"
                    onClick={handleSubscriptionPopupToggle}
                  >
                    Protect My Idea
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="popup-overlay" onClick={handlePopup}></div>
      </div>
      {showSubscriptionPopup && (
        <SubscriptionPopup handlePopup={handleSubscriptionPopupToggle} />
      )}
    </>
  );
};

export default WarningPopup;
