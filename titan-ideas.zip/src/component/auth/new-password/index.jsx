import React from "react";
import { Link } from "react-router-dom";
import { AuthBg, AuthIcon, AuthLogo } from "../../../assets/images";
import {
  SvgGoogleIcon,
  SvgAppleIcon,
} from "../../../assets/svg-files/SvgFiles";
const index = () => {
  return (
    <>
      <div className="auth-wrapper auth-wrp-hght">
        <div className="auth-wrapper-inner">
          <div className="auth-flex">
            <div className="auth-flex-50">
              <div
                className="auth-discription-image"
                style={{ backgroundImage: `url(${AuthBg})` }}
              >
                <div className="auth-discrption">
                  <div className="auth-discrption-inner">
                    <div className="auth-logo">
                      <img src={AuthLogo} alt="" />
                    </div>
                    <div className="auth-content">
                      <h4>Hey! Welcome to Titan Ideas</h4>
                      <p>Join Us and give information to people</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="auth-flex-50">
              <div className="auth-main">
                <div className="auth-form-main">
                  <div className="auth-inner-main auth-hgt-st">
                    <div className="auth-top-main">
                      <h3>
                        {" "}
                        <span>
                          <img src={AuthIcon} alt="" />
                        </span>{" "}
                        New Password{" "}
                      </h3>
                    </div>
                    <div className="auth-card">
                      <div className="auth-card-body">
                        <div className="auth-card-body-inner">
                          <div className="form-flex">
                            <div className="form-inner-flex-100">
                              <div className="form-inputs">
                                <label className="form-label">
                                  New password
                                </label>
                                <div className="input-wthicon">
                                  <input
                                    type="password"
                                    placeholder="Enter Your Password"
                                  />
                                  <div className="input-icon">
                                    <span>
                                      <i className="fa-regular fa-eye"></i>
                                    </span>
                                    <span style={{ display: "none" }}>
                                      <i className="fa-regular fa-eye-slash"></i>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-inner-flex-100">
                              <div className="form-inputs">
                                <label className="form-label">
                                  Confirm password
                                </label>
                                <div className="input-wthicon">
                                  <input
                                    type="password"
                                    placeholder="Enter Your Password"
                                  />
                                  <div className="input-icon">
                                    <span>
                                      <i className="fa-regular fa-eye"></i>
                                    </span>
                                    <span style={{ display: "none" }}>
                                      <i className="fa-regular fa-eye-slash"></i>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="auth-btn">
                            <Link to="/success" className="btn btn-primary">
                              Update Password
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
