import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Logo } from "../../../assets/images";
import ProfileDropdown from "../../../helper/ProfileDropdown";

const Header = () => {
  const [isFixed, setIsFixed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 71) {
        setIsFixed(true);
      } else {
        setIsFixed(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className={isFixed ? "fixed" : ""}>
      <div className="container">
        <div className="hdr-main">
          <div className="logo">
            <Link to="/">
              <img src={Logo} alt="Logo" />
            </Link>
          </div>
          <div className="hdr-navigation">
            <nav>
              <ul>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to="/about-us">About us</Link>
                </li>
                <li>
                  <Link to="/blog">Blogs</Link>
                </li>
                <li>
                  <Link to="/forum">Forum</Link>
                </li>
                <li>
                  <Link to="/contact">Contact us</Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="hdr-btn">
            {/* <div className="register-btn">
              <Link to="/sign-up">Register</Link>
            </div>
            <div className="login-btn">
              <Link to="/login" className="btn btn-primary">
                Login
              </Link>
            </div> */}
            <div className="rght-hdr">
              <div className="hdrmr-main">
                <ProfileDropdown />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
