import React from "react";
import { SvgDashcheckIcon } from "../../../assets/svg-files/SvgFiles";
import { Link } from "react-router-dom";

const SubcriptionPlan = () => {
  return (
    <div className="subscription-section">
      <div className="top-heading">
        <h3>Plans That Suit Your Vision</h3>
        <p>Upgrade anytime. All plans include a 30-day free trial.</p>
      </div>
      <div className="subscriprtion-list">
        <ul>
          {/* <li>
            <div className="card">
              <div className="card-body">
                <div className="subcription-crdheading">
                  <span className="subsp-icon">
                    <svg
                      width="20"
                      height="16"
                      viewBox="0 0 20 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.66663 10.0833L9.99996 14.25L18.3333 10.0833M9.99996 1.75L1.66663 5.91667L9.99996 10.0833L18.3333 5.91667L9.99996 1.75Z"
                        stroke="white"
                        stroke-width="1.66667"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                  <h4>Sponsor a post</h4>
                  <p>Starting from prices as low as</p>
                  <h3>₹50/Post</h3>
                </div>
                <div className="subscription-benifitlist">
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Post your ideas directly to a selected audience relevant to
                    your domain or interest.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Unlike free users, your ideas won’t be shown to everyone —
                    only to specific, filtered audiences.lected audience
                    relevant to your domain or interest.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Stand out with a premium badge next to your profile and
                    posts.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Appear more prominently within focused user groups.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Engage with users who matter most to your idea.
                  </p>
                </div>
                <div className="subscriptoncrd-btn">
                  <Link to="#" className="btn btn-primary">
                    Get Started
                  </Link>
                </div>
              </div>
            </div>
          </li> */}
          <li>
            <div className="card">
              <div className="card-body">
                <div className="subcription-crdheading">
                  <span className="subsp-icon">
                    <svg
                      width="20"
                      height="16"
                      viewBox="0 0 20 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M1.66663 10.0833L9.99996 14.25L18.3333 10.0833M9.99996 1.75L1.66663 5.91667L9.99996 10.0833L18.3333 5.91667L9.99996 1.75Z"
                        stroke="white"
                        stroke-width="1.66667"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                  <h4>Premium plan</h4>
                  <p>Unlock Exclusive Benefits</p>
                  <h3>₹1000/Month</h3>
                </div>
                <div className="subscription-benifitlist">
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Post your ideas directly to your selected target audience —
                    reach who matters most.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Your ideas will be seen by verified domain experts for
                    validation and credibility.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Get built-in IP protection from day one — included in your
                    membership.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Easily sign and upload required legal templates to safeguard
                    your ideas.
                  </p>
                  <p>
                    <span>
                      <SvgDashcheckIcon />
                    </span>
                    Get prepared for direct interactions with investors in
                    upcoming platform updates.
                  </p>
                </div>
                <div className="subscriptoncrd-btn">
                  <Link to="/home/payment" className="btn btn-primary">
                    Get Started
                  </Link>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default SubcriptionPlan;
