import React from "react";
import { BannerBg } from "../../../assets/images";
import { Link } from "react-router-dom";

const BannerSection = () => {
  return (
    <section
      className="banner-section"
      style={{ backgroundImage: `url(${BannerBg})` }}
    >
      <div className="container">
        <div className="banner-heading">
          <h5>Welcome to Titan Ideas</h5>
          <h1>Empowering <span>visionaries</span> by transforming raw ideas into successful <span>innovations</span>.</h1>
          <p>Titan Ideas is where your ideas find the support, validation, and collaboration they need to grow into powerful innovations. </p>
          <div className="banner-btn">
            <Link to="#" className="btn btn-primary">Explore</Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BannerSection;
