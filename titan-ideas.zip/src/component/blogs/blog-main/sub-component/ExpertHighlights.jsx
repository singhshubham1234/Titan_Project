import React, { useState } from "react";
import {
  ExpertImage1,
  ExpertImage2,
  ExpertImage3,
  ExpertImage4,
  ExpertImage5,
  Ornament1,
  Ornament2,
} from "../../../../assets/images";
import {
  SvgBigArrowLeftIcon,
  SvgBigArrowRightIcon,
  SvgDegreeLongArrowIcon,
} from "../../../../assets/svg-files/SvgFiles";
import { Link } from "react-router-dom";
// import "./ExpertHighlights.css";

const testimonials = [
  {
    name: "It was a very good experience",
    image: ExpertImage1,
    title: "It was a very good experience",
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu. Elementum felis magna pretium in tincidunt. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. urpis orci lectus maecenas.
     Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu`,
  },
  {
    name: "Lucky",
    image: ExpertImage2, // Replace with actual image path
    title: "It was a very good experience",
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu. Elementum felis magna pretium in tincidunt. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. urpis orci lectus maecenas.
     Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu`,
  },
  {
    name: "Lucky",
    image: ExpertImage3, // Replace with actual image path
    title: "It was a very good experience",
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu. Elementum felis magna pretium in tincidunt. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. urpis orci lectus maecenas.
     Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu`,
  },
  {
    name: "Lucky",
    image: ExpertImage4, // Replace with actual image path
    title: "It was a very good experience",
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu. Elementum felis magna pretium in tincidunt. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. urpis orci lectus maecenas.
     Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu`,
  },
  {
    name: "Lucky",
    image: ExpertImage5, // Replace with actual image path
    title: "It was a very good experience",
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu. Elementum felis magna pretium in tincidunt. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. urpis orci lectus maecenas.
     Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim arcu`,
  },
  // Add more testimonials here
];

const ExpertHighlights = () => {
  const [index, setIndex] = useState(0);

  const prev = () =>
    setIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  const next = () => setIndex((prev) => (prev + 1) % testimonials.length);

  return (
    <>
      <section className="experthighlights-section">
        <div className="container">
          <div className="expert-highlights">
            <h3 className="title">Expert Highlights</h3>

            <div className="testimonial-card">
              <div className="ornament1-image">
                <img src={Ornament1} alt="" />
              </div>
              <button className="nav left" onClick={prev}>
                <SvgBigArrowLeftIcon />
              </button>
              <div className="bubble">
                <h2>{testimonials[index].title}</h2>
                <p>{testimonials[index].content}</p>
                <div className="arrow-down"></div>
              </div>
              <button className="nav right" onClick={next}>
                <SvgBigArrowRightIcon />
              </button>
              <div className="ornament2-image">
                <img src={Ornament2} alt="" />
              </div>
            </div>

            <div className="avatars">
              {testimonials.map((t, i) => (
                <img
                  key={i}
                  src={t.image}
                  alt={t.name}
                  className={`avatar ${i === index ? "active" : ""}`}
                  onClick={() => setIndex(i)}
                />
              ))}
            </div>

            <p className="author">
              <strong>{testimonials[index].name}</strong>
            </p>
          </div>
          <div className="featured-viewsbtn">
            <Link to="/expert">
              View All
              <span>
                <SvgDegreeLongArrowIcon />
              </span>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default ExpertHighlights;
