import React from "react";
import Payment from "./sub-component/Payment";

const index = () => {
  return (
    <>
      <Payment />
    </>
  );
};

export default index;
