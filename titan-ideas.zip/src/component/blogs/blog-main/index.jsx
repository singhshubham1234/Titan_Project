import React from "react";
import { BlogBannerSection, ExpertHighlights, FeaturedStory, UserTestimonial } from "./sub-component";

const index = () => {
  return (
    <>
      <BlogBannerSection />
      <FeaturedStory/>
      <ExpertHighlights/>
      <UserTestimonial/>
    </>
  );
};

export default index;
