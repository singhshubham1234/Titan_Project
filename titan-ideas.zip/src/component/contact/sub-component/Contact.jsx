import React from "react";
import Select from "react-select";

const Contact = () => {
  const Domain = [{ value: "Expert", label: "Expert" }];
  return (
    <>
      <section className="contect-section">
        <div className="container">
          <div className="card">
            <div className="card-body">
              <div className="contact-main">
                <div className="contact-form">
                  <div className="contact-heading">
                    <h3>Contact Us</h3>
                    <p>
                      Fill out the form below, and our team will respond as soon
                      as possible.
                    </p>
                  </div>
                  <div className="form-flex">
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Full name</label>
                        <input type="text" placeholder="Full name" />
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Email address</label>
                        <input type="text" placeholder="Email address" />
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Join as</label>
                        <Select
                          options={Domain}
                          placeholder="Select a domain"
                        />
                      </div>
                    </div>
                    <div className="form-inner-flex-100">
                      <div className="form-inputs">
                        <label className="form-label">Message</label>
                        <textarea
                          cols={4}
                          rows={4}
                          type="text"
                          className="form-control"
                          placeholder="Tell us a little about the Idea..."
                        />
                      </div>
                    </div>
                  </div>
                  <div className="contactus-btn">
                    <button className="btn btn-primary">Submit</button>
                  </div>
                </div>
                <div className="contact-descp">
                  <div className="contact-heading">
                    <h3>Welcome to our community</h3>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry's
                      standard.
                    </p>
                  </div>
                  <div className="contact-addresslist">
                    <p>
                      <span>
                        <svg
                          width="20"
                          height="16"
                          viewBox="0 0 20 16"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M20 3.53516V13.0002C20 13.7654 19.7077 14.5017 19.1827 15.0584C18.6578 15.6152 17.9399 15.9503 17.176 15.9952L17 16.0002H3C2.23479 16.0002 1.49849 15.7078 0.941739 15.1829C0.384993 14.6579 0.0498925 13.94 0.00500011 13.1762L0 13.0002V3.53516L9.445 9.83216L9.561 9.89816C9.69771 9.96495 9.84785 9.99967 10 9.99967C10.1522 9.99967 10.3023 9.96495 10.439 9.89816L10.555 9.83216L20 3.53516Z"
                            fill="#D7B434"
                          />
                          <path
                            d="M16.9999 0C18.0799 0 19.0269 0.57 19.5549 1.427L9.99995 7.797L0.444946 1.427C0.695739 1.01982 1.04024 0.6785 1.44972 0.431489C1.8592 0.184479 2.3218 0.0389373 2.79895 0.00699997L2.99995 0H16.9999Z"
                            fill="#D7B434"
                          />
                        </svg>
                      </span>
                      email@example.com
                    </p>
                    <p>
                      <span>
                        <svg
                          width="23"
                          height="24"
                          viewBox="0 0 23 24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M22.3969 16.9152L19.1804 13.6987C18.0317 12.55 16.0788 13.0095 15.6193 14.5028C15.2747 15.5368 14.1259 16.1111 13.0921 15.8813C10.7946 15.307 7.693 12.3202 7.11863 9.90788C6.77401 8.87397 7.46326 7.72523 8.49712 7.38065C9.99048 6.92116 10.45 4.9683 9.30124 3.81956L6.08477 0.603089C5.16578 -0.201029 3.78729 -0.201029 2.98317 0.603089L0.800565 2.78569C-1.38204 5.08317 1.03031 11.1715 6.42939 16.5706C11.8285 21.9697 17.9168 24.4969 20.2143 22.1994L22.3969 20.0168C23.201 19.0978 23.201 17.7193 22.3969 16.9152Z"
                            fill="#D7B434"
                          />
                        </svg>
                      </span>
                      +65-955-575-54
                    </p>
                    <p>
                      <span>
                        <svg
                          width="14"
                          height="20"
                          viewBox="0 0 14 20"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M7 9.5C6.33696 9.5 5.70107 9.23661 5.23223 8.76777C4.76339 8.29893 4.5 7.66304 4.5 7C4.5 6.33696 4.76339 5.70107 5.23223 5.23223C5.70107 4.76339 6.33696 4.5 7 4.5C7.66304 4.5 8.29893 4.76339 8.76777 5.23223C9.23661 5.70107 9.5 6.33696 9.5 7C9.5 7.3283 9.43534 7.65339 9.3097 7.95671C9.18406 8.26002 8.99991 8.53562 8.76777 8.76777C8.53562 8.99991 8.26002 9.18406 7.95671 9.3097C7.65339 9.43534 7.3283 9.5 7 9.5ZM7 0C5.14348 0 3.36301 0.737498 2.05025 2.05025C0.737498 3.36301 0 5.14348 0 7C0 12.25 7 20 7 20C7 20 14 12.25 14 7C14 5.14348 13.2625 3.36301 11.9497 2.05025C10.637 0.737498 8.85652 0 7 0Z"
                            fill="#D7B434"
                          />
                        </svg>
                      </span>
                      Betime Building 246 Macpherson Road #02-03
                      City:  Singapore
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
