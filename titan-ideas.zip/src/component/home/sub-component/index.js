export { default as BannerSection } from "./BannerSection";
export { default as DiscoverSection } from "./DiscoverSection";
export { default as RareRatingSystemSection } from "./RareRatingSystem";
export { default as ShareIdeasSection } from "./ShareIdeas";
export { default as ExpertsTrustSection } from "./ExpertsTrust";
export { default as TestimonialSection } from "./Testimonial";
export { default as JoinUsSection } from "./JoinUsSection";
