import React from "react";
import { Link } from "react-router-dom";
import {
  DiscEducation,
  DiscFinance,
  Dischealth,
  DiscMarking,
  DiscTechnology,
} from "../../../assets/images";
import { SvgSearchIcon } from "../../../assets/svg-files/SvgFiles";
import Pagination from "../../../helper/Pagination";

const ForumList = () => {
  const discoverData = [
    { image: DiscEducation, title: "Education" },
    { image: DiscFinance, title: "Finance" },
    { image: DiscTechnology, title: "Technology" },
    { image: DiscMarking, title: "Marketing" },
    { image: Dischealth, title: "Health Care" },
    { image: DiscEducation, title: "Education" },
    { image: DiscFinance, title: "Finance" },
    { image: DiscTechnology, title: "Technology" },
    { image: DiscMarking, title: "Marketing" },
    { image: Dischealth, title: "Health Care" },
    { image: DiscEducation, title: "Education" },
    { image: DiscFinance, title: "Finance" },
    { image: DiscTechnology, title: "Technology" },
    { image: DiscFinance, title: "Finance" },
    { image: DiscMarking, title: "Marketing" },
  ];
  return (
    <>
      <section className="forumlist-section">
        <div className="container">
          <div className="top-heading">
            <h6>Discover our forums</h6>
            <h3>Explore our Diverse Industry Domains</h3>
            <div className="authsearch-field">
              <input type="text" name="" id="" placeholder="Search Topics" />
              <span>
                <SvgSearchIcon />
              </span>
            </div>
          </div>
          <div className="discover-list mt-50">
            <ul>
              {discoverData.map((item, index) => (
                <li key={index}>
                  <Link to="/home" className="discover-card">
                    <div className="disc-image">
                      <img src={item.image} alt={item.title} />
                    </div>
                    <h4>{item.title}</h4>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua.
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <Pagination />
        </div>
      </section>
    </>
  );
};

export default ForumList;
