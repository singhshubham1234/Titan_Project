import React from "react";
import { BlogBannerSection, UserTestimonial } from "./sub-component";

const index = () => {
  return (
    <>
      <BlogBannerSection />
      <UserTestimonial />
    </>
  );
};

export default index;
