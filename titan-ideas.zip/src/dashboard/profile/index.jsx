import React, { useState } from "react";
import { ProfileMain, UserPost } from "./sub-component";
import AllFollowerTab from "../home/sub-component/following-tab/AllFollowerTab";
import ActiveMembersTab from "../home/sub-component/following-tab/ActiveMembersTab";
import TopExpertsTab from "../home/sub-component/following-tab/TopExpertsTab";

const index = () => {
  const [FollowerActiveTab, setFollowerActiveTab] = useState(0);

  const Followertabs = [
    { title: "All ", content: <AllFollowerTab /> },
    {
      title: "Active Members",
      content: <ActiveMembersTab />,
    },
    {
      title: "Top Experts",
      content: <TopExpertsTab />,
    },
  ];
  return (
    <>
      <div className="postgrid-main pofile-postfollower">
        <div className="postgrid-innermn">
          <ProfileMain />
          <UserPost />
        </div>
        <div className="postgrid-innermn">
          <div className="post-tablist">
            <div className="following-fiel">
              <span>
                <svg
                  width="15"
                  height="8"
                  viewBox="0 0 15 8"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M6.9147 0.217211L0.239632 6.27705C0.0851213 6.4172 0 6.6043 0 6.8038C0 7.00329 0.0851213 7.19039 0.239632 7.33055L0.731092 7.77681C1.05133 8.0672 1.57182 8.0672 1.89157 7.77681L7.49689 2.68822L13.1084 7.78246C13.2629 7.92261 13.4689 8 13.6885 8C13.9084 8 14.1144 7.92261 14.269 7.78246L14.7604 7.33619C14.9149 7.19593 15 7.00894 15 6.80944C15 6.60995 14.9149 6.42285 14.7604 6.28269L8.0792 0.217211C7.9242 0.0767221 7.71725 -0.000440598 7.49726 1.90735e-06C7.2764 -0.000440598 7.06958 0.0767221 6.9147 0.217211Z"
                    fill="white"
                  />
                </svg>
              </span>
              <p>All Following</p>
            </div>
          </div>
          <div className="following-list">
            <div className="follower-tab">
              <ul>
                {Followertabs.map((followertab, index) => (
                  <li key={index} onClick={() => setFollowerActiveTab(index)}>
                    <div
                      className={`prfl-title ${
                        index == FollowerActiveTab ? "followeractive" : ""
                      }`}
                    >
                      <span className="tab-title">{followertab.title}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <div className="user-table-detail">
              <div className="tab-content">
                {Followertabs[FollowerActiveTab].content}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default index;
