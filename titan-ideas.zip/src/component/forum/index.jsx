import React from "react";
import { ForumBannerSection, ForumListSection } from "./sub-component";

const index = () => {
  return (
    <>
      <ForumBannerSection />
      <ForumListSection />
    </>
  );
};

export default index;
